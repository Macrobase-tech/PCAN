//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CCPDemo.rc
//
#define IDD_CCPDEMO_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_BTNCONNECT                  1000
#define IDC_BUTTON2                     1001
#define IDC_BTNDISCONNECT               1001
#define IDC_BUTTON3                     1002
#define IDC_BTNGETVERSION               1002
#define IDC_BUTTON4                     1003
#define IDC_BTNTEST                     1003
#define IDC_BUTTON5                     1004
#define IDC_BTNEXCHANGE                 1004
#define IDC_BUTTON6                     1005
#define IDC_BTNGETID                    1005
#define IDC_EDIT1                       1006
#define IDC_EDIT2                       1007
#define IDC_EDIT3                       1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
