//---------------------------------------------------------------------------

#ifndef CCPDemoH
#define CCPDemoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>

#include "PCCP.h"

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *btnConnect;
	TButton *btnDisconnect;
	TButton *btnGetVersion;
	TButton *btnExchange;
	TButton *btnGetId;
	TButton *btnTest;
	TLabel *Label1;
	TLabel *Label3;
	TLabel *Label2;
	TLabel *laSlaveInfo;
	TLabel *laSlaveId;
	TLabel *laSlaveVersion;
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall btnConnectClick(TObject *Sender);
	void __fastcall btnDisconnectClick(TObject *Sender);
	void __fastcall btnTestClick(TObject *Sender);
	void __fastcall btnGetVersionClick(TObject *Sender);
	void __fastcall btnExchangeClick(TObject *Sender);
	void __fastcall btnGetIdClick(TObject *Sender);
	
private:
	  TCCPHandle m_PccpHandle;
	  TPCANHandle m_Channel;
	  TPCANBaudrate m_Baudrate;
	  TCCPSlaveData m_SlaveData;
	  TCCPExchangeData m_ExchangeData;

	  AnsiString GetErrorText(TCCPResult errorCode);

public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
