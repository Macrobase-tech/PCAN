﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.laSlaveId = New System.Windows.Forms.Label
        Me.laSlaveInfo = New System.Windows.Forms.Label
        Me.laVersion = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnSlaveId = New System.Windows.Forms.Button
        Me.btnExchangeId = New System.Windows.Forms.Button
        Me.btnGetVersion = New System.Windows.Forms.Button
        Me.btnDisconnect = New System.Windows.Forms.Button
        Me.btnTest = New System.Windows.Forms.Button
        Me.btnConnect = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'laSlaveId
        '
        Me.laSlaveId.AutoEllipsis = True
        Me.laSlaveId.Location = New System.Drawing.Point(85, 157)
        Me.laSlaveId.Name = "laSlaveId"
        Me.laSlaveId.Size = New System.Drawing.Size(282, 13)
        Me.laSlaveId.TabIndex = 23
        Me.laSlaveId.Text = "_________"
        '
        'laSlaveInfo
        '
        Me.laSlaveInfo.AutoEllipsis = True
        Me.laSlaveInfo.Location = New System.Drawing.Point(85, 134)
        Me.laSlaveInfo.Name = "laSlaveInfo"
        Me.laSlaveInfo.Size = New System.Drawing.Size(282, 13)
        Me.laSlaveInfo.TabIndex = 22
        Me.laSlaveInfo.Text = "_________"
        '
        'laVersion
        '
        Me.laVersion.AutoSize = True
        Me.laVersion.Location = New System.Drawing.Point(85, 94)
        Me.laVersion.Name = "laVersion"
        Me.laVersion.Size = New System.Drawing.Size(22, 13)
        Me.laVersion.TabIndex = 21
        Me.laVersion.Text = "0.0"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(7, 157)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(51, 13)
        Me.label3.TabIndex = 20
        Me.label3.Text = "Slave ID:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(7, 134)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(58, 13)
        Me.label2.TabIndex = 19
        Me.label2.Text = "Slave Info:"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(7, 94)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(45, 13)
        Me.label1.TabIndex = 18
        Me.label1.Text = "Version:"
        '
        'btnSlaveId
        '
        Me.btnSlaveId.Enabled = False
        Me.btnSlaveId.Location = New System.Drawing.Point(272, 44)
        Me.btnSlaveId.Name = "btnSlaveId"
        Me.btnSlaveId.Size = New System.Drawing.Size(95, 23)
        Me.btnSlaveId.TabIndex = 17
        Me.btnSlaveId.Text = "Get slave Id"
        Me.btnSlaveId.UseVisualStyleBackColor = True
        '
        'btnExchangeId
        '
        Me.btnExchangeId.Enabled = False
        Me.btnExchangeId.Location = New System.Drawing.Point(272, 15)
        Me.btnExchangeId.Name = "btnExchangeId"
        Me.btnExchangeId.Size = New System.Drawing.Size(95, 23)
        Me.btnExchangeId.TabIndex = 16
        Me.btnExchangeId.Text = "Exchange Ids"
        Me.btnExchangeId.UseVisualStyleBackColor = True
        '
        'btnGetVersion
        '
        Me.btnGetVersion.Enabled = False
        Me.btnGetVersion.Location = New System.Drawing.Point(191, 15)
        Me.btnGetVersion.Name = "btnGetVersion"
        Me.btnGetVersion.Size = New System.Drawing.Size(75, 23)
        Me.btnGetVersion.TabIndex = 15
        Me.btnGetVersion.Text = "Get Version"
        Me.btnGetVersion.UseVisualStyleBackColor = True
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Enabled = False
        Me.btnDisconnect.Location = New System.Drawing.Point(88, 15)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(75, 23)
        Me.btnDisconnect.TabIndex = 14
        Me.btnDisconnect.Text = "Disconnect"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        '
        'btnTest
        '
        Me.btnTest.Location = New System.Drawing.Point(7, 44)
        Me.btnTest.Name = "btnTest"
        Me.btnTest.Size = New System.Drawing.Size(75, 23)
        Me.btnTest.TabIndex = 13
        Me.btnTest.Text = "Test"
        Me.btnTest.UseVisualStyleBackColor = True
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(7, 15)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(75, 23)
        Me.btnConnect.TabIndex = 12
        Me.btnConnect.Text = "Connect"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(374, 184)
        Me.Controls.Add(Me.laSlaveId)
        Me.Controls.Add(Me.laSlaveInfo)
        Me.Controls.Add(Me.laVersion)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnSlaveId)
        Me.Controls.Add(Me.btnExchangeId)
        Me.Controls.Add(Me.btnGetVersion)
        Me.Controls.Add(Me.btnDisconnect)
        Me.Controls.Add(Me.btnTest)
        Me.Controls.Add(Me.btnConnect)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents laSlaveId As System.Windows.Forms.Label
    Private WithEvents laSlaveInfo As System.Windows.Forms.Label
    Private WithEvents laVersion As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnSlaveId As System.Windows.Forms.Button
    Private WithEvents btnExchangeId As System.Windows.Forms.Button
    Private WithEvents btnGetVersion As System.Windows.Forms.Button
    Private WithEvents btnDisconnect As System.Windows.Forms.Button
    Private WithEvents btnTest As System.Windows.Forms.Button
    Private WithEvents btnConnect As System.Windows.Forms.Button

End Class
