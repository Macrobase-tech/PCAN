﻿namespace CCPDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnGetVersion = new System.Windows.Forms.Button();
            this.btnExchangeId = new System.Windows.Forms.Button();
            this.btnSlaveId = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.laVersion = new System.Windows.Forms.Label();
            this.laSlaveInfo = new System.Windows.Forms.Label();
            this.laSlaveId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(12, 12);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 0;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(12, 41);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 1;
            this.btnTest.Text = "Test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Location = new System.Drawing.Point(93, 12);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(75, 23);
            this.btnDisconnect.TabIndex = 2;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnGetVersion
            // 
            this.btnGetVersion.Enabled = false;
            this.btnGetVersion.Location = new System.Drawing.Point(196, 12);
            this.btnGetVersion.Name = "btnGetVersion";
            this.btnGetVersion.Size = new System.Drawing.Size(75, 23);
            this.btnGetVersion.TabIndex = 3;
            this.btnGetVersion.Text = "Get Version";
            this.btnGetVersion.UseVisualStyleBackColor = true;
            this.btnGetVersion.Click += new System.EventHandler(this.btnGetVersion_Click);
            // 
            // btnExchangeId
            // 
            this.btnExchangeId.Enabled = false;
            this.btnExchangeId.Location = new System.Drawing.Point(277, 12);
            this.btnExchangeId.Name = "btnExchangeId";
            this.btnExchangeId.Size = new System.Drawing.Size(95, 23);
            this.btnExchangeId.TabIndex = 4;
            this.btnExchangeId.Text = "Exchange Ids";
            this.btnExchangeId.UseVisualStyleBackColor = true;
            this.btnExchangeId.Click += new System.EventHandler(this.btnExchangeId_Click);
            // 
            // btnSlaveId
            // 
            this.btnSlaveId.Enabled = false;
            this.btnSlaveId.Location = new System.Drawing.Point(277, 41);
            this.btnSlaveId.Name = "btnSlaveId";
            this.btnSlaveId.Size = new System.Drawing.Size(95, 23);
            this.btnSlaveId.TabIndex = 5;
            this.btnSlaveId.Text = "Get slave Id";
            this.btnSlaveId.UseVisualStyleBackColor = true;
            this.btnSlaveId.Click += new System.EventHandler(this.btnSlaveId_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Version:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Slave Info:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Slave ID:";
            // 
            // laVersion
            // 
            this.laVersion.AutoSize = true;
            this.laVersion.Location = new System.Drawing.Point(90, 91);
            this.laVersion.Name = "laVersion";
            this.laVersion.Size = new System.Drawing.Size(22, 13);
            this.laVersion.TabIndex = 9;
            this.laVersion.Text = "0.0";
            // 
            // laSlaveInfo
            // 
            this.laSlaveInfo.AutoEllipsis = true;
            this.laSlaveInfo.Location = new System.Drawing.Point(90, 131);
            this.laSlaveInfo.Name = "laSlaveInfo";
            this.laSlaveInfo.Size = new System.Drawing.Size(282, 13);
            this.laSlaveInfo.TabIndex = 10;
            this.laSlaveInfo.Text = "_________";
            // 
            // laSlaveId
            // 
            this.laSlaveId.AutoEllipsis = true;
            this.laSlaveId.Location = new System.Drawing.Point(90, 154);
            this.laSlaveId.Name = "laSlaveId";
            this.laSlaveId.Size = new System.Drawing.Size(282, 13);
            this.laSlaveId.TabIndex = 11;
            this.laSlaveId.Text = "_________";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 194);
            this.Controls.Add(this.laSlaveId);
            this.Controls.Add(this.laSlaveInfo);
            this.Controls.Add(this.laVersion);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSlaveId);
            this.Controls.Add(this.btnExchangeId);
            this.Controls.Add(this.btnGetVersion);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnConnect);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PCAN-CCP Example";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnGetVersion;
        private System.Windows.Forms.Button btnExchangeId;
        private System.Windows.Forms.Button btnSlaveId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label laVersion;
        private System.Windows.Forms.Label laSlaveInfo;
        private System.Windows.Forms.Label laSlaveId;
    }
}

