﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.label9 = New System.Windows.Forms.Label
        Me.label10 = New System.Windows.Forms.Label
        Me.label11 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.label13 = New System.Windows.Forms.Label
        Me.label14 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnDisconnect = New System.Windows.Forms.Button
        Me.btnConnect = New System.Windows.Forms.Button
        Me.btnFinalize = New System.Windows.Forms.Button
        Me.btnInit = New System.Windows.Forms.Button
        Me.chbFD = New System.Windows.Forms.CheckBox
        Me.SuspendLayout()
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(11, 202)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(104, 13)
        Me.label9.TabIndex = 32
        Me.label9.Text = "XCP transport Layer:"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(11, 178)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(102, 13)
        Me.label10.TabIndex = 31
        Me.label10.Text = "XCP Protocol Layer:"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(11, 156)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(62, 13)
        Me.label11.TabIndex = 30
        Me.label11.Text = "MAX_DTO:"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(11, 134)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(61, 13)
        Me.label12.TabIndex = 29
        Me.label12.Text = "MAX_CTO:"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Location = New System.Drawing.Point(11, 112)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(118, 13)
        Me.label13.TabIndex = 28
        Me.label13.Text = "COMM_MODE_BASIC:"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Location = New System.Drawing.Point(11, 89)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(85, 13)
        Me.label14.TabIndex = 27
        Me.label14.Text = "Resource Mask:"
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(136, 202)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(119, 13)
        Me.label6.TabIndex = 26
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(136, 178)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(119, 13)
        Me.label5.TabIndex = 25
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(136, 156)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(119, 13)
        Me.label4.TabIndex = 24
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(136, 134)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(119, 13)
        Me.label3.TabIndex = 23
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(136, 112)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(119, 13)
        Me.label2.TabIndex = 22
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(136, 89)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(119, 13)
        Me.label1.TabIndex = 21
        '
        'btnDisconnect
        '
        Me.btnDisconnect.Enabled = False
        Me.btnDisconnect.Location = New System.Drawing.Point(182, 50)
        Me.btnDisconnect.Name = "btnDisconnect"
        Me.btnDisconnect.Size = New System.Drawing.Size(119, 23)
        Me.btnDisconnect.TabIndex = 20
        Me.btnDisconnect.Text = "Disconnect Slave"
        Me.btnDisconnect.UseVisualStyleBackColor = True
        '
        'btnConnect
        '
        Me.btnConnect.Enabled = False
        Me.btnConnect.Location = New System.Drawing.Point(11, 50)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.Size = New System.Drawing.Size(119, 23)
        Me.btnConnect.TabIndex = 19
        Me.btnConnect.Text = "Connect Slave"
        Me.btnConnect.UseVisualStyleBackColor = True
        '
        'btnFinalize
        '
        Me.btnFinalize.Enabled = False
        Me.btnFinalize.Location = New System.Drawing.Point(182, 10)
        Me.btnFinalize.Name = "btnFinalize"
        Me.btnFinalize.Size = New System.Drawing.Size(119, 34)
        Me.btnFinalize.TabIndex = 18
        Me.btnFinalize.Text = "Finalize Communication"
        Me.btnFinalize.UseVisualStyleBackColor = True
        '
        'btnInit
        '
        Me.btnInit.Location = New System.Drawing.Point(11, 10)
        Me.btnInit.Name = "btnInit"
        Me.btnInit.Size = New System.Drawing.Size(119, 34)
        Me.btnInit.TabIndex = 17
        Me.btnInit.Text = "Initialize Communication"
        Me.btnInit.UseVisualStyleBackColor = True
        '
        'chbFD
        '
        Me.chbFD.AutoSize = True
        Me.chbFD.Location = New System.Drawing.Point(136, 20)
        Me.chbFD.Name = "chbFD"
        Me.chbFD.Size = New System.Drawing.Size(40, 17)
        Me.chbFD.TabIndex = 33
        Me.chbFD.Text = "FD"
        Me.chbFD.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(306, 225)
        Me.Controls.Add(Me.chbFD)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.label12)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.label14)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnDisconnect)
        Me.Controls.Add(Me.btnConnect)
        Me.Controls.Add(Me.btnFinalize)
        Me.Controls.Add(Me.btnInit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "XCP Connection Sample"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents btnDisconnect As System.Windows.Forms.Button
    Private WithEvents btnConnect As System.Windows.Forms.Button
    Private WithEvents btnFinalize As System.Windows.Forms.Button
    Private WithEvents btnInit As System.Windows.Forms.Button
    Private WithEvents chbFD As System.Windows.Forms.CheckBox

End Class
