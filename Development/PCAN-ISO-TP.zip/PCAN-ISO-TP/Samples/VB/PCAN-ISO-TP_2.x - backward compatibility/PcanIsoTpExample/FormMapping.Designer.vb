﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMapping
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.buttonOk = New System.Windows.Forms.Button()
        Me.buttonCancel = New System.Windows.Forms.Button()
        Me.labelRemoteAddr = New System.Windows.Forms.Label()
        Me.labelTargetAddr = New System.Windows.Forms.Label()
        Me.labelSrcAddr = New System.Windows.Forms.Label()
        Me.labelTargetType = New System.Windows.Forms.Label()
        Me.labelMsgType = New System.Windows.Forms.Label()
        Me.labelCanIdType = New System.Windows.Forms.Label()
        Me.radioButtonCanId29b = New System.Windows.Forms.RadioButton()
        Me.radioButtonCanId11b = New System.Windows.Forms.RadioButton()
        Me.numericUpDownCanIdResp = New System.Windows.Forms.NumericUpDown()
        Me.numericUpDownCanId = New System.Windows.Forms.NumericUpDown()
        Me.labelFormat = New System.Windows.Forms.Label()
        Me.labelCanId = New System.Windows.Forms.Label()
        Me.labelCanIdResp = New System.Windows.Forms.Label()
        Me.numericUpDownRemoteAddr = New System.Windows.Forms.NumericUpDown()
        Me.numericUpDownTargetAddr = New System.Windows.Forms.NumericUpDown()
        Me.numericUpDownSourceAddr = New System.Windows.Forms.NumericUpDown()
        Me.comboBoxTargetType = New System.Windows.Forms.ComboBox()
        Me.comboBoxMsgType = New System.Windows.Forms.ComboBox()
        Me.comboBoxFormat = New System.Windows.Forms.ComboBox()
        CType(Me.numericUpDownCanIdResp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownCanId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownRemoteAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownTargetAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownSourceAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'buttonOk
        '
        Me.buttonOk.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.buttonOk.Location = New System.Drawing.Point(278, 256)
        Me.buttonOk.Name = "buttonOk"
        Me.buttonOk.Size = New System.Drawing.Size(75, 23)
        Me.buttonOk.TabIndex = 41
        Me.buttonOk.Text = "OK"
        Me.buttonOk.UseVisualStyleBackColor = True
        '
        'buttonCancel
        '
        Me.buttonCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.buttonCancel.Location = New System.Drawing.Point(359, 256)
        Me.buttonCancel.Name = "buttonCancel"
        Me.buttonCancel.Size = New System.Drawing.Size(75, 23)
        Me.buttonCancel.TabIndex = 42
        Me.buttonCancel.Text = "Cancel"
        Me.buttonCancel.UseVisualStyleBackColor = True
        '
        'labelRemoteAddr
        '
        Me.labelRemoteAddr.AutoSize = True
        Me.labelRemoteAddr.Location = New System.Drawing.Point(12, 219)
        Me.labelRemoteAddr.Name = "labelRemoteAddr"
        Me.labelRemoteAddr.Size = New System.Drawing.Size(113, 13)
        Me.labelRemoteAddr.TabIndex = 39
        Me.labelRemoteAddr.Text = "Remote address (hex):"
        '
        'labelTargetAddr
        '
        Me.labelTargetAddr.AutoSize = True
        Me.labelTargetAddr.Location = New System.Drawing.Point(12, 193)
        Me.labelTargetAddr.Name = "labelTargetAddr"
        Me.labelTargetAddr.Size = New System.Drawing.Size(107, 13)
        Me.labelTargetAddr.TabIndex = 37
        Me.labelTargetAddr.Text = "Target address (hex):"
        '
        'labelSrcAddr
        '
        Me.labelSrcAddr.AutoSize = True
        Me.labelSrcAddr.Location = New System.Drawing.Point(12, 167)
        Me.labelSrcAddr.Name = "labelSrcAddr"
        Me.labelSrcAddr.Size = New System.Drawing.Size(110, 13)
        Me.labelSrcAddr.TabIndex = 35
        Me.labelSrcAddr.Text = "Source address (hex):"
        '
        'labelTargetType
        '
        Me.labelTargetType.AutoSize = True
        Me.labelTargetType.Location = New System.Drawing.Point(12, 88)
        Me.labelTargetType.Name = "labelTargetType"
        Me.labelTargetType.Size = New System.Drawing.Size(118, 13)
        Me.labelTargetType.TabIndex = 29
        Me.labelTargetType.Text = "Target addressing type:"
        '
        'labelMsgType
        '
        Me.labelMsgType.AutoSize = True
        Me.labelMsgType.Location = New System.Drawing.Point(12, 34)
        Me.labelMsgType.Name = "labelMsgType"
        Me.labelMsgType.Size = New System.Drawing.Size(76, 13)
        Me.labelMsgType.TabIndex = 25
        Me.labelMsgType.Text = "Message type:"
        '
        'labelCanIdType
        '
        Me.labelCanIdType.AutoSize = True
        Me.labelCanIdType.Location = New System.Drawing.Point(12, 11)
        Me.labelCanIdType.Name = "labelCanIdType"
        Me.labelCanIdType.Size = New System.Drawing.Size(69, 13)
        Me.labelCanIdType.TabIndex = 22
        Me.labelCanIdType.Text = "CAN ID type:"
        '
        'radioButtonCanId29b
        '
        Me.radioButtonCanId29b.AutoSize = True
        Me.radioButtonCanId29b.Location = New System.Drawing.Point(205, 9)
        Me.radioButtonCanId29b.Name = "radioButtonCanId29b"
        Me.radioButtonCanId29b.Size = New System.Drawing.Size(56, 17)
        Me.radioButtonCanId29b.TabIndex = 24
        Me.radioButtonCanId29b.TabStop = True
        Me.radioButtonCanId29b.Text = "29 bits"
        Me.radioButtonCanId29b.UseVisualStyleBackColor = True
        '
        'radioButtonCanId11b
        '
        Me.radioButtonCanId11b.AutoSize = True
        Me.radioButtonCanId11b.Location = New System.Drawing.Point(143, 9)
        Me.radioButtonCanId11b.Name = "radioButtonCanId11b"
        Me.radioButtonCanId11b.Size = New System.Drawing.Size(56, 17)
        Me.radioButtonCanId11b.TabIndex = 23
        Me.radioButtonCanId11b.TabStop = True
        Me.radioButtonCanId11b.Text = "11 bits"
        Me.radioButtonCanId11b.UseVisualStyleBackColor = True
        '
        'numericUpDownCanIdResp
        '
        Me.numericUpDownCanIdResp.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numericUpDownCanIdResp.Hexadecimal = True
        Me.numericUpDownCanIdResp.Location = New System.Drawing.Point(143, 138)
        Me.numericUpDownCanIdResp.Name = "numericUpDownCanIdResp"
        Me.numericUpDownCanIdResp.Size = New System.Drawing.Size(291, 20)
        Me.numericUpDownCanIdResp.TabIndex = 34
        '
        'numericUpDownCanId
        '
        Me.numericUpDownCanId.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numericUpDownCanId.Hexadecimal = True
        Me.numericUpDownCanId.Location = New System.Drawing.Point(143, 112)
        Me.numericUpDownCanId.Name = "numericUpDownCanId"
        Me.numericUpDownCanId.Size = New System.Drawing.Size(291, 20)
        Me.numericUpDownCanId.TabIndex = 32
        '
        'labelFormat
        '
        Me.labelFormat.AutoSize = True
        Me.labelFormat.Location = New System.Drawing.Point(12, 61)
        Me.labelFormat.Name = "labelFormat"
        Me.labelFormat.Size = New System.Drawing.Size(65, 13)
        Me.labelFormat.TabIndex = 27
        Me.labelFormat.Text = "Format type:"
        '
        'labelCanId
        '
        Me.labelCanId.AutoSize = True
        Me.labelCanId.Location = New System.Drawing.Point(12, 114)
        Me.labelCanId.Name = "labelCanId"
        Me.labelCanId.Size = New System.Drawing.Size(72, 13)
        Me.labelCanId.TabIndex = 31
        Me.labelCanId.Text = "CAN ID (hex):"
        '
        'labelCanIdResp
        '
        Me.labelCanIdResp.AutoSize = True
        Me.labelCanIdResp.Location = New System.Drawing.Point(12, 140)
        Me.labelCanIdResp.Name = "labelCanIdResp"
        Me.labelCanIdResp.Size = New System.Drawing.Size(118, 13)
        Me.labelCanIdResp.TabIndex = 33
        Me.labelCanIdResp.Text = "CAN ID response (hex):"
        '
        'numericUpDownRemoteAddr
        '
        Me.numericUpDownRemoteAddr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numericUpDownRemoteAddr.Hexadecimal = True
        Me.numericUpDownRemoteAddr.Location = New System.Drawing.Point(143, 217)
        Me.numericUpDownRemoteAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownRemoteAddr.Name = "numericUpDownRemoteAddr"
        Me.numericUpDownRemoteAddr.Size = New System.Drawing.Size(291, 20)
        Me.numericUpDownRemoteAddr.TabIndex = 40
        '
        'numericUpDownTargetAddr
        '
        Me.numericUpDownTargetAddr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numericUpDownTargetAddr.Hexadecimal = True
        Me.numericUpDownTargetAddr.Location = New System.Drawing.Point(143, 191)
        Me.numericUpDownTargetAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownTargetAddr.Name = "numericUpDownTargetAddr"
        Me.numericUpDownTargetAddr.Size = New System.Drawing.Size(291, 20)
        Me.numericUpDownTargetAddr.TabIndex = 38
        '
        'numericUpDownSourceAddr
        '
        Me.numericUpDownSourceAddr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.numericUpDownSourceAddr.Hexadecimal = True
        Me.numericUpDownSourceAddr.Location = New System.Drawing.Point(143, 165)
        Me.numericUpDownSourceAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownSourceAddr.Name = "numericUpDownSourceAddr"
        Me.numericUpDownSourceAddr.Size = New System.Drawing.Size(291, 20)
        Me.numericUpDownSourceAddr.TabIndex = 36
        '
        'comboBoxTargetType
        '
        Me.comboBoxTargetType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxTargetType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxTargetType.FormattingEnabled = True
        Me.comboBoxTargetType.Location = New System.Drawing.Point(143, 85)
        Me.comboBoxTargetType.Name = "comboBoxTargetType"
        Me.comboBoxTargetType.Size = New System.Drawing.Size(291, 21)
        Me.comboBoxTargetType.TabIndex = 30
        '
        'comboBoxMsgType
        '
        Me.comboBoxMsgType.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxMsgType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxMsgType.FormattingEnabled = True
        Me.comboBoxMsgType.Location = New System.Drawing.Point(143, 31)
        Me.comboBoxMsgType.Name = "comboBoxMsgType"
        Me.comboBoxMsgType.Size = New System.Drawing.Size(291, 21)
        Me.comboBoxMsgType.TabIndex = 26
        '
        'comboBoxFormat
        '
        Me.comboBoxFormat.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxFormat.FormattingEnabled = True
        Me.comboBoxFormat.Location = New System.Drawing.Point(143, 58)
        Me.comboBoxFormat.Name = "comboBoxFormat"
        Me.comboBoxFormat.Size = New System.Drawing.Size(291, 21)
        Me.comboBoxFormat.TabIndex = 28
        '
        'FormMapping
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(446, 289)
        Me.Controls.Add(Me.buttonOk)
        Me.Controls.Add(Me.buttonCancel)
        Me.Controls.Add(Me.labelRemoteAddr)
        Me.Controls.Add(Me.labelTargetAddr)
        Me.Controls.Add(Me.labelSrcAddr)
        Me.Controls.Add(Me.labelTargetType)
        Me.Controls.Add(Me.labelMsgType)
        Me.Controls.Add(Me.labelCanIdType)
        Me.Controls.Add(Me.radioButtonCanId29b)
        Me.Controls.Add(Me.radioButtonCanId11b)
        Me.Controls.Add(Me.numericUpDownCanIdResp)
        Me.Controls.Add(Me.numericUpDownCanId)
        Me.Controls.Add(Me.labelFormat)
        Me.Controls.Add(Me.labelCanId)
        Me.Controls.Add(Me.labelCanIdResp)
        Me.Controls.Add(Me.numericUpDownRemoteAddr)
        Me.Controls.Add(Me.numericUpDownTargetAddr)
        Me.Controls.Add(Me.numericUpDownSourceAddr)
        Me.Controls.Add(Me.comboBoxTargetType)
        Me.Controls.Add(Me.comboBoxMsgType)
        Me.Controls.Add(Me.comboBoxFormat)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FormMapping"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "ISO-TP Mapping"
        CType(Me.numericUpDownCanIdResp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownCanId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownRemoteAddr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownTargetAddr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownSourceAddr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents buttonOk As System.Windows.Forms.Button
    Private WithEvents buttonCancel As System.Windows.Forms.Button
    Private WithEvents labelRemoteAddr As System.Windows.Forms.Label
    Private WithEvents labelTargetAddr As System.Windows.Forms.Label
    Private WithEvents labelSrcAddr As System.Windows.Forms.Label
    Private WithEvents labelTargetType As System.Windows.Forms.Label
    Private WithEvents labelMsgType As System.Windows.Forms.Label
    Private WithEvents labelCanIdType As System.Windows.Forms.Label
    Private WithEvents radioButtonCanId29b As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonCanId11b As System.Windows.Forms.RadioButton
    Private WithEvents numericUpDownCanIdResp As System.Windows.Forms.NumericUpDown
    Private WithEvents numericUpDownCanId As System.Windows.Forms.NumericUpDown
    Private WithEvents labelFormat As System.Windows.Forms.Label
    Private WithEvents labelCanId As System.Windows.Forms.Label
    Private WithEvents labelCanIdResp As System.Windows.Forms.Label
    Private WithEvents numericUpDownRemoteAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents numericUpDownTargetAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents numericUpDownSourceAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents comboBoxTargetType As System.Windows.Forms.ComboBox
    Private WithEvents comboBoxMsgType As System.Windows.Forms.ComboBox
    Private WithEvents comboBoxFormat As System.Windows.Forms.ComboBox
End Class
