﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.columnHeaderMappingMsgType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgLen = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgResult = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgTargetType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgFormat = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgIdType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgRemoteAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgTargetAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgSourceAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.checkBoxMsgShowPeriod = New System.Windows.Forms.CheckBox()
        Me.radioButtonMsgManual = New System.Windows.Forms.RadioButton()
        Me.radioButtonMsgEvent = New System.Windows.Forms.RadioButton()
        Me.listViewMsgs = New System.Windows.Forms.ListView()
        Me.columnHeaderMsgCount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgTimestamp = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMsgData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.groupBoxMsgRead = New System.Windows.Forms.GroupBox()
        Me.buttonMsgClear = New System.Windows.Forms.Button()
        Me.radioButtonMsgTimer = New System.Windows.Forms.RadioButton()
        Me.buttonMsgRead = New System.Windows.Forms.Button()
        Me.tabPageMessages = New System.Windows.Forms.TabPage()
        Me.groupBoxMsgWrite = New System.Windows.Forms.GroupBox()
        Me.numericUpDownRemoteAddr = New System.Windows.Forms.NumericUpDown()
        Me.numericUpDownTargetAddr = New System.Windows.Forms.NumericUpDown()
        Me.numericUpDownSourceAddr = New System.Windows.Forms.NumericUpDown()
        Me.buttonMsgDataFill = New System.Windows.Forms.Button()
        Me.labelMsgRemoteAddr = New System.Windows.Forms.Label()
        Me.labelMsgTargetAddr = New System.Windows.Forms.Label()
        Me.textBoxMsgData = New System.Windows.Forms.TextBox()
        Me.labelMsgMapping = New System.Windows.Forms.Label()
        Me.comboBoxMsgMapping = New System.Windows.Forms.ComboBox()
        Me.labelMsgData = New System.Windows.Forms.Label()
        Me.buttonMsgWrite = New System.Windows.Forms.Button()
        Me.labelMsgLength = New System.Windows.Forms.Label()
        Me.labelMsgSourceAddr = New System.Windows.Forms.Label()
        Me.numericUpDownMsgLength = New System.Windows.Forms.NumericUpDown()
        Me.columnHeaderMappingRemoteAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMappingFormat = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMappingTargetAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.timerRead = New System.Windows.Forms.Timer(Me.components)
        Me.columnHeaderMappingSourceAddr = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.buttonParamVersion = New System.Windows.Forms.Button()
        Me.comboBoxHwType = New System.Windows.Forms.ComboBox()
        Me.comboBoxInterrupt = New System.Windows.Forms.ComboBox()
        Me.labelConnInterrupt = New System.Windows.Forms.Label()
        Me.comboBoxIoPort = New System.Windows.Forms.ComboBox()
        Me.labelConnIoPort = New System.Windows.Forms.Label()
        Me.labelConnHwType = New System.Windows.Forms.Label()
        Me.comboBoxBaudrate = New System.Windows.Forms.ComboBox()
        Me.labelConnBaudrate = New System.Windows.Forms.Label()
        Me.buttonParamReset = New System.Windows.Forms.Button()
        Me.groupBoxParamInfo = New System.Windows.Forms.GroupBox()
        Me.buttonParamStatus = New System.Windows.Forms.Button()
        Me.listBoxParamInfo = New System.Windows.Forms.ListBox()
        Me.buttonParamInfoClear = New System.Windows.Forms.Button()
        Me.tabPageParameters = New System.Windows.Forms.TabPage()
        Me.groupBoxParamCfg = New System.Windows.Forms.GroupBox()
        Me.labelParameter = New System.Windows.Forms.Label()
        Me.comboBoxParameter = New System.Windows.Forms.ComboBox()
        Me.labelParamActivation = New System.Windows.Forms.Label()
        Me.radioButtonParamActive = New System.Windows.Forms.RadioButton()
        Me.radioButtonParamInactive = New System.Windows.Forms.RadioButton()
        Me.labelParamValue = New System.Windows.Forms.Label()
        Me.numericUpDownParamValue = New System.Windows.Forms.NumericUpDown()
        Me.buttonParamGet = New System.Windows.Forms.Button()
        Me.buttonParamSet = New System.Windows.Forms.Button()
        Me.tabControlMain = New System.Windows.Forms.TabControl()
        Me.tabPageMappings = New System.Windows.Forms.TabPage()
        Me.buttonMappingSample = New System.Windows.Forms.Button()
        Me.buttonMappingDel = New System.Windows.Forms.Button()
        Me.buttonMappingAdd = New System.Windows.Forms.Button()
        Me.listViewMappings = New System.Windows.Forms.ListView()
        Me.columnHeaderMappingCanId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMappingCanIdResponse = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMappingTargetType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderMappingCanIdType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.buttonHwRefresh = New System.Windows.Forms.Button()
        Me.comboBoxChannel = New System.Windows.Forms.ComboBox()
        Me.labelConnHardware = New System.Windows.Forms.Label()
        Me.buttonInit = New System.Windows.Forms.Button()
        Me.buttonRelease = New System.Windows.Forms.Button()
        Me.groupBoxConnection = New System.Windows.Forms.GroupBox()
        Me.timerDisplay = New System.Windows.Forms.Timer(Me.components)
        Me.buttonMappingSave = New System.Windows.Forms.Button()
        Me.buttonMappingLoad = New System.Windows.Forms.Button()
        Me.textBoxCanFdBitrate = New System.Windows.Forms.TextBox()
        Me.labelConnBitRate = New System.Windows.Forms.Label()
        Me.checkBoxCanFd = New System.Windows.Forms.CheckBox()
        Me.checkBoxFDMessage = New System.Windows.Forms.CheckBox()
        Me.checkBoxBRS = New System.Windows.Forms.CheckBox()
        Me.checkBoxHasPriority = New System.Windows.Forms.CheckBox()
        Me.numericUpDownPriority = New System.Windows.Forms.NumericUpDown()
        Me.groupBoxMsgRead.SuspendLayout()
        Me.tabPageMessages.SuspendLayout()
        Me.groupBoxMsgWrite.SuspendLayout()
        CType(Me.numericUpDownRemoteAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownTargetAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownSourceAddr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numericUpDownMsgLength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.groupBoxParamInfo.SuspendLayout()
        Me.tabPageParameters.SuspendLayout()
        Me.groupBoxParamCfg.SuspendLayout()
        CType(Me.numericUpDownParamValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabControlMain.SuspendLayout()
        Me.tabPageMappings.SuspendLayout()
        Me.groupBoxConnection.SuspendLayout()
        CType(Me.numericUpDownPriority, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'columnHeaderMappingMsgType
        '
        Me.columnHeaderMappingMsgType.Text = "MsgType"
        Me.columnHeaderMappingMsgType.Width = 100
        '
        'columnHeaderMsgLen
        '
        Me.columnHeaderMsgLen.Text = "Length"
        Me.columnHeaderMsgLen.Width = 45
        '
        'columnHeaderMsgResult
        '
        Me.columnHeaderMsgResult.Text = "Result"
        Me.columnHeaderMsgResult.Width = 42
        '
        'columnHeaderMsgTargetType
        '
        Me.columnHeaderMsgTargetType.Text = "Target type"
        Me.columnHeaderMsgTargetType.Width = 70
        '
        'columnHeaderMsgFormat
        '
        Me.columnHeaderMsgFormat.Text = "Format"
        Me.columnHeaderMsgFormat.Width = 63
        '
        'columnHeaderMsgType
        '
        Me.columnHeaderMsgType.Text = "Type"
        Me.columnHeaderMsgType.Width = 72
        '
        'columnHeaderMsgIdType
        '
        Me.columnHeaderMsgIdType.Text = "ID"
        Me.columnHeaderMsgIdType.Width = 45
        '
        'columnHeaderMsgRemoteAddr
        '
        Me.columnHeaderMsgRemoteAddr.Text = "Remote"
        Me.columnHeaderMsgRemoteAddr.Width = 50
        '
        'columnHeaderMsgTargetAddr
        '
        Me.columnHeaderMsgTargetAddr.Text = "Target"
        Me.columnHeaderMsgTargetAddr.Width = 45
        '
        'columnHeaderMsgSourceAddr
        '
        Me.columnHeaderMsgSourceAddr.Text = "Source"
        Me.columnHeaderMsgSourceAddr.Width = 50
        '
        'checkBoxMsgShowPeriod
        '
        Me.checkBoxMsgShowPeriod.AutoSize = True
        Me.checkBoxMsgShowPeriod.Checked = True
        Me.checkBoxMsgShowPeriod.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBoxMsgShowPeriod.Location = New System.Drawing.Point(374, 15)
        Me.checkBoxMsgShowPeriod.Name = "checkBoxMsgShowPeriod"
        Me.checkBoxMsgShowPeriod.Size = New System.Drawing.Size(123, 17)
        Me.checkBoxMsgShowPeriod.TabIndex = 3
        Me.checkBoxMsgShowPeriod.Text = "Timestamp as period"
        Me.checkBoxMsgShowPeriod.UseVisualStyleBackColor = True
        '
        'radioButtonMsgManual
        '
        Me.radioButtonMsgManual.AutoSize = True
        Me.radioButtonMsgManual.Location = New System.Drawing.Point(276, 14)
        Me.radioButtonMsgManual.Name = "radioButtonMsgManual"
        Me.radioButtonMsgManual.Size = New System.Drawing.Size(89, 17)
        Me.radioButtonMsgManual.TabIndex = 2
        Me.radioButtonMsgManual.Text = "Manual Read"
        Me.radioButtonMsgManual.UseVisualStyleBackColor = True
        '
        'radioButtonMsgEvent
        '
        Me.radioButtonMsgEvent.AutoSize = True
        Me.radioButtonMsgEvent.Location = New System.Drawing.Point(131, 14)
        Me.radioButtonMsgEvent.Name = "radioButtonMsgEvent"
        Me.radioButtonMsgEvent.Size = New System.Drawing.Size(139, 17)
        Me.radioButtonMsgEvent.TabIndex = 1
        Me.radioButtonMsgEvent.Text = "Reading using an Event"
        Me.radioButtonMsgEvent.UseVisualStyleBackColor = True
        '
        'listViewMsgs
        '
        Me.listViewMsgs.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listViewMsgs.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeaderMsgSourceAddr, Me.columnHeaderMsgTargetAddr, Me.columnHeaderMsgRemoteAddr, Me.columnHeaderMsgIdType, Me.columnHeaderMsgType, Me.columnHeaderMsgFormat, Me.columnHeaderMsgTargetType, Me.columnHeaderMsgResult, Me.columnHeaderMsgLen, Me.columnHeaderMsgCount, Me.columnHeaderMsgTimestamp, Me.columnHeaderMsgData})
        Me.listViewMsgs.FullRowSelect = True
        Me.listViewMsgs.Location = New System.Drawing.Point(6, 37)
        Me.listViewMsgs.MultiSelect = False
        Me.listViewMsgs.Name = "listViewMsgs"
        Me.listViewMsgs.Size = New System.Drawing.Size(791, 128)
        Me.listViewMsgs.TabIndex = 4
        Me.listViewMsgs.UseCompatibleStateImageBehavior = False
        Me.listViewMsgs.View = System.Windows.Forms.View.Details
        '
        'columnHeaderMsgCount
        '
        Me.columnHeaderMsgCount.Text = "Count"
        Me.columnHeaderMsgCount.Width = 50
        '
        'columnHeaderMsgTimestamp
        '
        Me.columnHeaderMsgTimestamp.Text = "Timestamp"
        Me.columnHeaderMsgTimestamp.Width = 64
        '
        'columnHeaderMsgData
        '
        Me.columnHeaderMsgData.Text = "Data"
        Me.columnHeaderMsgData.Width = 181
        '
        'groupBoxMsgRead
        '
        Me.groupBoxMsgRead.BackColor = System.Drawing.SystemColors.Control
        Me.groupBoxMsgRead.Controls.Add(Me.checkBoxMsgShowPeriod)
        Me.groupBoxMsgRead.Controls.Add(Me.radioButtonMsgManual)
        Me.groupBoxMsgRead.Controls.Add(Me.radioButtonMsgEvent)
        Me.groupBoxMsgRead.Controls.Add(Me.listViewMsgs)
        Me.groupBoxMsgRead.Controls.Add(Me.buttonMsgClear)
        Me.groupBoxMsgRead.Controls.Add(Me.radioButtonMsgTimer)
        Me.groupBoxMsgRead.Controls.Add(Me.buttonMsgRead)
        Me.groupBoxMsgRead.Dock = System.Windows.Forms.DockStyle.Fill
        Me.groupBoxMsgRead.Location = New System.Drawing.Point(0, 0)
        Me.groupBoxMsgRead.Name = "groupBoxMsgRead"
        Me.groupBoxMsgRead.Size = New System.Drawing.Size(876, 171)
        Me.groupBoxMsgRead.TabIndex = 0
        Me.groupBoxMsgRead.TabStop = False
        Me.groupBoxMsgRead.Text = " Messages Reading "
        '
        'buttonMsgClear
        '
        Me.buttonMsgClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonMsgClear.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonMsgClear.Location = New System.Drawing.Point(805, 66)
        Me.buttonMsgClear.Name = "buttonMsgClear"
        Me.buttonMsgClear.Size = New System.Drawing.Size(65, 23)
        Me.buttonMsgClear.TabIndex = 6
        Me.buttonMsgClear.Text = "Clear"
        Me.buttonMsgClear.UseVisualStyleBackColor = True
        '
        'radioButtonMsgTimer
        '
        Me.radioButtonMsgTimer.AutoSize = True
        Me.radioButtonMsgTimer.Checked = True
        Me.radioButtonMsgTimer.Location = New System.Drawing.Point(8, 14)
        Me.radioButtonMsgTimer.Name = "radioButtonMsgTimer"
        Me.radioButtonMsgTimer.Size = New System.Drawing.Size(117, 17)
        Me.radioButtonMsgTimer.TabIndex = 0
        Me.radioButtonMsgTimer.TabStop = True
        Me.radioButtonMsgTimer.Text = "Read using a Timer"
        Me.radioButtonMsgTimer.UseVisualStyleBackColor = True
        '
        'buttonMsgRead
        '
        Me.buttonMsgRead.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonMsgRead.Enabled = False
        Me.buttonMsgRead.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonMsgRead.Location = New System.Drawing.Point(805, 37)
        Me.buttonMsgRead.Name = "buttonMsgRead"
        Me.buttonMsgRead.Size = New System.Drawing.Size(65, 23)
        Me.buttonMsgRead.TabIndex = 5
        Me.buttonMsgRead.Text = "Read"
        Me.buttonMsgRead.UseVisualStyleBackColor = True
        '
        'tabPageMessages
        '
        Me.tabPageMessages.Controls.Add(Me.groupBoxMsgRead)
        Me.tabPageMessages.Controls.Add(Me.groupBoxMsgWrite)
        Me.tabPageMessages.Location = New System.Drawing.Point(4, 22)
        Me.tabPageMessages.Name = "tabPageMessages"
        Me.tabPageMessages.Size = New System.Drawing.Size(876, 320)
        Me.tabPageMessages.TabIndex = 2
        Me.tabPageMessages.Text = "Messages"
        Me.tabPageMessages.UseVisualStyleBackColor = True
        '
        'groupBoxMsgWrite
        '
        Me.groupBoxMsgWrite.BackColor = System.Drawing.SystemColors.Control
        Me.groupBoxMsgWrite.Controls.Add(Me.numericUpDownPriority)
        Me.groupBoxMsgWrite.Controls.Add(Me.checkBoxHasPriority)
        Me.groupBoxMsgWrite.Controls.Add(Me.checkBoxBRS)
        Me.groupBoxMsgWrite.Controls.Add(Me.checkBoxFDMessage)
        Me.groupBoxMsgWrite.Controls.Add(Me.numericUpDownRemoteAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.numericUpDownTargetAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.numericUpDownSourceAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.buttonMsgDataFill)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgRemoteAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgTargetAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.textBoxMsgData)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgMapping)
        Me.groupBoxMsgWrite.Controls.Add(Me.comboBoxMsgMapping)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgData)
        Me.groupBoxMsgWrite.Controls.Add(Me.buttonMsgWrite)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgLength)
        Me.groupBoxMsgWrite.Controls.Add(Me.labelMsgSourceAddr)
        Me.groupBoxMsgWrite.Controls.Add(Me.numericUpDownMsgLength)
        Me.groupBoxMsgWrite.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.groupBoxMsgWrite.Location = New System.Drawing.Point(0, 171)
        Me.groupBoxMsgWrite.Name = "groupBoxMsgWrite"
        Me.groupBoxMsgWrite.Size = New System.Drawing.Size(876, 149)
        Me.groupBoxMsgWrite.TabIndex = 1
        Me.groupBoxMsgWrite.TabStop = False
        Me.groupBoxMsgWrite.Text = "Write Messages"
        '
        'numericUpDownRemoteAddr
        '
        Me.numericUpDownRemoteAddr.BackColor = System.Drawing.Color.White
        Me.numericUpDownRemoteAddr.Hexadecimal = True
        Me.numericUpDownRemoteAddr.Location = New System.Drawing.Point(413, 39)
        Me.numericUpDownRemoteAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownRemoteAddr.Name = "numericUpDownRemoteAddr"
        Me.numericUpDownRemoteAddr.Size = New System.Drawing.Size(65, 20)
        Me.numericUpDownRemoteAddr.TabIndex = 7
        '
        'numericUpDownTargetAddr
        '
        Me.numericUpDownTargetAddr.BackColor = System.Drawing.Color.White
        Me.numericUpDownTargetAddr.Hexadecimal = True
        Me.numericUpDownTargetAddr.Location = New System.Drawing.Point(338, 39)
        Me.numericUpDownTargetAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownTargetAddr.Name = "numericUpDownTargetAddr"
        Me.numericUpDownTargetAddr.Size = New System.Drawing.Size(65, 20)
        Me.numericUpDownTargetAddr.TabIndex = 5
        '
        'numericUpDownSourceAddr
        '
        Me.numericUpDownSourceAddr.BackColor = System.Drawing.Color.White
        Me.numericUpDownSourceAddr.Hexadecimal = True
        Me.numericUpDownSourceAddr.Location = New System.Drawing.Point(260, 39)
        Me.numericUpDownSourceAddr.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownSourceAddr.Name = "numericUpDownSourceAddr"
        Me.numericUpDownSourceAddr.Size = New System.Drawing.Size(65, 20)
        Me.numericUpDownSourceAddr.TabIndex = 3
        '
        'buttonMsgDataFill
        '
        Me.buttonMsgDataFill.Cursor = System.Windows.Forms.Cursors.Default
        Me.buttonMsgDataFill.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonMsgDataFill.Location = New System.Drawing.Point(565, 37)
        Me.buttonMsgDataFill.Name = "buttonMsgDataFill"
        Me.buttonMsgDataFill.Size = New System.Drawing.Size(65, 23)
        Me.buttonMsgDataFill.TabIndex = 10
        Me.buttonMsgDataFill.Text = "Fill"
        '
        'labelMsgRemoteAddr
        '
        Me.labelMsgRemoteAddr.AutoSize = True
        Me.labelMsgRemoteAddr.Location = New System.Drawing.Point(410, 21)
        Me.labelMsgRemoteAddr.Name = "labelMsgRemoteAddr"
        Me.labelMsgRemoteAddr.Size = New System.Drawing.Size(75, 13)
        Me.labelMsgRemoteAddr.TabIndex = 6
        Me.labelMsgRemoteAddr.Text = "Remote (Hex):"
        '
        'labelMsgTargetAddr
        '
        Me.labelMsgTargetAddr.AutoSize = True
        Me.labelMsgTargetAddr.Location = New System.Drawing.Point(335, 21)
        Me.labelMsgTargetAddr.Name = "labelMsgTargetAddr"
        Me.labelMsgTargetAddr.Size = New System.Drawing.Size(69, 13)
        Me.labelMsgTargetAddr.TabIndex = 4
        Me.labelMsgTargetAddr.Text = "Target (Hex):"
        '
        'textBoxMsgData
        '
        Me.textBoxMsgData.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxMsgData.Location = New System.Drawing.Point(9, 82)
        Me.textBoxMsgData.MaxLength = 4095
        Me.textBoxMsgData.Multiline = True
        Me.textBoxMsgData.Name = "textBoxMsgData"
        Me.textBoxMsgData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.textBoxMsgData.Size = New System.Drawing.Size(790, 61)
        Me.textBoxMsgData.TabIndex = 12
        '
        'labelMsgMapping
        '
        Me.labelMsgMapping.AutoSize = True
        Me.labelMsgMapping.Location = New System.Drawing.Point(6, 21)
        Me.labelMsgMapping.Name = "labelMsgMapping"
        Me.labelMsgMapping.Size = New System.Drawing.Size(51, 13)
        Me.labelMsgMapping.TabIndex = 0
        Me.labelMsgMapping.Text = "Mapping:"
        '
        'comboBoxMsgMapping
        '
        Me.comboBoxMsgMapping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxMsgMapping.FormattingEnabled = True
        Me.comboBoxMsgMapping.Location = New System.Drawing.Point(9, 37)
        Me.comboBoxMsgMapping.Name = "comboBoxMsgMapping"
        Me.comboBoxMsgMapping.Size = New System.Drawing.Size(236, 21)
        Me.comboBoxMsgMapping.TabIndex = 1
        '
        'labelMsgData
        '
        Me.labelMsgData.AutoSize = True
        Me.labelMsgData.Location = New System.Drawing.Point(6, 66)
        Me.labelMsgData.Name = "labelMsgData"
        Me.labelMsgData.Size = New System.Drawing.Size(61, 13)
        Me.labelMsgData.TabIndex = 11
        Me.labelMsgData.Text = "Data (Hex):"
        '
        'buttonMsgWrite
        '
        Me.buttonMsgWrite.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonMsgWrite.Cursor = System.Windows.Forms.Cursors.Default
        Me.buttonMsgWrite.Enabled = False
        Me.buttonMsgWrite.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonMsgWrite.Location = New System.Drawing.Point(805, 80)
        Me.buttonMsgWrite.Name = "buttonMsgWrite"
        Me.buttonMsgWrite.Size = New System.Drawing.Size(65, 23)
        Me.buttonMsgWrite.TabIndex = 13
        Me.buttonMsgWrite.Text = "Write"
        '
        'labelMsgLength
        '
        Me.labelMsgLength.AutoSize = True
        Me.labelMsgLength.Location = New System.Drawing.Point(491, 21)
        Me.labelMsgLength.Name = "labelMsgLength"
        Me.labelMsgLength.Size = New System.Drawing.Size(43, 13)
        Me.labelMsgLength.TabIndex = 8
        Me.labelMsgLength.Text = "Length:"
        '
        'labelMsgSourceAddr
        '
        Me.labelMsgSourceAddr.AutoSize = True
        Me.labelMsgSourceAddr.Location = New System.Drawing.Point(257, 21)
        Me.labelMsgSourceAddr.Name = "labelMsgSourceAddr"
        Me.labelMsgSourceAddr.Size = New System.Drawing.Size(72, 13)
        Me.labelMsgSourceAddr.TabIndex = 2
        Me.labelMsgSourceAddr.Text = "Source (Hex):"
        '
        'numericUpDownMsgLength
        '
        Me.numericUpDownMsgLength.BackColor = System.Drawing.Color.White
        Me.numericUpDownMsgLength.Location = New System.Drawing.Point(494, 39)
        Me.numericUpDownMsgLength.Maximum = New Decimal(New Integer() {4095, 0, 0, 0})
        Me.numericUpDownMsgLength.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numericUpDownMsgLength.Name = "numericUpDownMsgLength"
        Me.numericUpDownMsgLength.Size = New System.Drawing.Size(65, 20)
        Me.numericUpDownMsgLength.TabIndex = 9
        Me.numericUpDownMsgLength.Value = New Decimal(New Integer() {8, 0, 0, 0})
        '
        'columnHeaderMappingRemoteAddr
        '
        Me.columnHeaderMappingRemoteAddr.Text = "RA"
        Me.columnHeaderMappingRemoteAddr.Width = 50
        '
        'columnHeaderMappingFormat
        '
        Me.columnHeaderMappingFormat.Text = "Format"
        Me.columnHeaderMappingFormat.Width = 100
        '
        'columnHeaderMappingTargetAddr
        '
        Me.columnHeaderMappingTargetAddr.Text = "TA"
        Me.columnHeaderMappingTargetAddr.Width = 50
        '
        'timerRead
        '
        Me.timerRead.Interval = 50
        '
        'columnHeaderMappingSourceAddr
        '
        Me.columnHeaderMappingSourceAddr.Text = "SA"
        Me.columnHeaderMappingSourceAddr.Width = 50
        '
        'buttonParamVersion
        '
        Me.buttonParamVersion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamVersion.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamVersion.Location = New System.Drawing.Point(731, 19)
        Me.buttonParamVersion.Name = "buttonParamVersion"
        Me.buttonParamVersion.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamVersion.TabIndex = 12
        Me.buttonParamVersion.Text = "Version"
        Me.buttonParamVersion.UseVisualStyleBackColor = True
        '
        'comboBoxHwType
        '
        Me.comboBoxHwType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxHwType.Items.AddRange(New Object() {"ISA-82C200", "ISA-SJA1000", "ISA-PHYTEC", "DNG-82C200", "DNG-82C200 EPP", "DNG-SJA1000", "DNG-SJA1000 EPP"})
        Me.comboBoxHwType.Location = New System.Drawing.Point(326, 32)
        Me.comboBoxHwType.Name = "comboBoxHwType"
        Me.comboBoxHwType.Size = New System.Drawing.Size(120, 21)
        Me.comboBoxHwType.TabIndex = 50
        '
        'comboBoxInterrupt
        '
        Me.comboBoxInterrupt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxInterrupt.Items.AddRange(New Object() {"3", "4", "5", "7", "9", "10", "11", "12", "15"})
        Me.comboBoxInterrupt.Location = New System.Drawing.Point(513, 32)
        Me.comboBoxInterrupt.Name = "comboBoxInterrupt"
        Me.comboBoxInterrupt.Size = New System.Drawing.Size(55, 21)
        Me.comboBoxInterrupt.TabIndex = 52
        '
        'labelConnInterrupt
        '
        Me.labelConnInterrupt.Location = New System.Drawing.Point(515, 15)
        Me.labelConnInterrupt.Name = "labelConnInterrupt"
        Me.labelConnInterrupt.Size = New System.Drawing.Size(53, 23)
        Me.labelConnInterrupt.TabIndex = 56
        Me.labelConnInterrupt.Text = "Interrupt:"
        '
        'comboBoxIoPort
        '
        Me.comboBoxIoPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxIoPort.Items.AddRange(New Object() {"0100", "0120", "0140", "0200", "0220", "0240", "0260", "0278", "0280", "02A0", "02C0", "02E0", "02E8", "02F8", "0300", "0320", "0340", "0360", "0378", "0380", "03BC", "03E0", "03E8", "03F8"})
        Me.comboBoxIoPort.Location = New System.Drawing.Point(452, 32)
        Me.comboBoxIoPort.Name = "comboBoxIoPort"
        Me.comboBoxIoPort.Size = New System.Drawing.Size(55, 21)
        Me.comboBoxIoPort.TabIndex = 51
        '
        'labelConnIoPort
        '
        Me.labelConnIoPort.Location = New System.Drawing.Point(452, 15)
        Me.labelConnIoPort.Name = "labelConnIoPort"
        Me.labelConnIoPort.Size = New System.Drawing.Size(55, 23)
        Me.labelConnIoPort.TabIndex = 55
        Me.labelConnIoPort.Text = "I/O Port:"
        '
        'labelConnHwType
        '
        Me.labelConnHwType.Location = New System.Drawing.Point(327, 15)
        Me.labelConnHwType.Name = "labelConnHwType"
        Me.labelConnHwType.Size = New System.Drawing.Size(90, 23)
        Me.labelConnHwType.TabIndex = 54
        Me.labelConnHwType.Text = "Hardware Type:"
        '
        'comboBoxBaudrate
        '
        Me.comboBoxBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxBaudrate.Items.AddRange(New Object() {"1 MBit/sec", "800 kBit/s", "500 kBit/sec", "250 kBit/sec", "125 kBit/sec", "100 kBit/sec", "95,238 kBit/s", "83,333 kBit/s", "50 kBit/sec", "47,619 kBit/s", "33,333 kBit/s", "20 kBit/sec", "10 kBit/sec", "5 kBit/sec"})
        Me.comboBoxBaudrate.Location = New System.Drawing.Point(204, 32)
        Me.comboBoxBaudrate.Name = "comboBoxBaudrate"
        Me.comboBoxBaudrate.Size = New System.Drawing.Size(116, 21)
        Me.comboBoxBaudrate.TabIndex = 49
        '
        'labelConnBaudrate
        '
        Me.labelConnBaudrate.Location = New System.Drawing.Point(204, 15)
        Me.labelConnBaudrate.Name = "labelConnBaudrate"
        Me.labelConnBaudrate.Size = New System.Drawing.Size(56, 23)
        Me.labelConnBaudrate.TabIndex = 53
        Me.labelConnBaudrate.Text = "Baudrate:"
        '
        'buttonParamReset
        '
        Me.buttonParamReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamReset.Enabled = False
        Me.buttonParamReset.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamReset.Location = New System.Drawing.Point(802, 48)
        Me.buttonParamReset.Name = "buttonParamReset"
        Me.buttonParamReset.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamReset.TabIndex = 15
        Me.buttonParamReset.Text = "Reset"
        Me.buttonParamReset.UseVisualStyleBackColor = True
        '
        'groupBoxParamInfo
        '
        Me.groupBoxParamInfo.BackColor = System.Drawing.SystemColors.Control
        Me.groupBoxParamInfo.Controls.Add(Me.buttonParamReset)
        Me.groupBoxParamInfo.Controls.Add(Me.buttonParamStatus)
        Me.groupBoxParamInfo.Controls.Add(Me.buttonParamVersion)
        Me.groupBoxParamInfo.Controls.Add(Me.listBoxParamInfo)
        Me.groupBoxParamInfo.Controls.Add(Me.buttonParamInfoClear)
        Me.groupBoxParamInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.groupBoxParamInfo.Location = New System.Drawing.Point(3, 61)
        Me.groupBoxParamInfo.Name = "groupBoxParamInfo"
        Me.groupBoxParamInfo.Size = New System.Drawing.Size(870, 256)
        Me.groupBoxParamInfo.TabIndex = 10
        Me.groupBoxParamInfo.TabStop = False
        Me.groupBoxParamInfo.Text = "Information"
        '
        'buttonParamStatus
        '
        Me.buttonParamStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamStatus.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamStatus.Location = New System.Drawing.Point(731, 48)
        Me.buttonParamStatus.Name = "buttonParamStatus"
        Me.buttonParamStatus.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamStatus.TabIndex = 14
        Me.buttonParamStatus.Text = "Status"
        Me.buttonParamStatus.UseVisualStyleBackColor = True
        '
        'listBoxParamInfo
        '
        Me.listBoxParamInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listBoxParamInfo.FormattingEnabled = True
        Me.listBoxParamInfo.Items.AddRange(New Object() {"Select a Hardware and a configuration for it. Then click ""Initialize"" button", "When activated, configure ISO-TP mappings in order to transmit and receive ISO-TP" &
                " messages.", "---", "Note that to successfully transmit ISO-TP messages, you need a valid ISO-TP node " &
                "to communicate with.", "You can run a second instance of this application on another channel to do so.", "---"})
        Me.listBoxParamInfo.Location = New System.Drawing.Point(6, 19)
        Me.listBoxParamInfo.Name = "listBoxParamInfo"
        Me.listBoxParamInfo.ScrollAlwaysVisible = True
        Me.listBoxParamInfo.Size = New System.Drawing.Size(716, 225)
        Me.listBoxParamInfo.TabIndex = 11
        '
        'buttonParamInfoClear
        '
        Me.buttonParamInfoClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamInfoClear.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamInfoClear.Location = New System.Drawing.Point(802, 19)
        Me.buttonParamInfoClear.Name = "buttonParamInfoClear"
        Me.buttonParamInfoClear.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamInfoClear.TabIndex = 13
        Me.buttonParamInfoClear.Text = "Clear"
        Me.buttonParamInfoClear.UseVisualStyleBackColor = True
        '
        'tabPageParameters
        '
        Me.tabPageParameters.Controls.Add(Me.groupBoxParamInfo)
        Me.tabPageParameters.Controls.Add(Me.groupBoxParamCfg)
        Me.tabPageParameters.Location = New System.Drawing.Point(4, 22)
        Me.tabPageParameters.Name = "tabPageParameters"
        Me.tabPageParameters.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPageParameters.Size = New System.Drawing.Size(876, 320)
        Me.tabPageParameters.TabIndex = 3
        Me.tabPageParameters.Text = "Parameters"
        Me.tabPageParameters.UseVisualStyleBackColor = True
        '
        'groupBoxParamCfg
        '
        Me.groupBoxParamCfg.BackColor = System.Drawing.SystemColors.Control
        Me.groupBoxParamCfg.Controls.Add(Me.labelParameter)
        Me.groupBoxParamCfg.Controls.Add(Me.comboBoxParameter)
        Me.groupBoxParamCfg.Controls.Add(Me.labelParamActivation)
        Me.groupBoxParamCfg.Controls.Add(Me.radioButtonParamActive)
        Me.groupBoxParamCfg.Controls.Add(Me.radioButtonParamInactive)
        Me.groupBoxParamCfg.Controls.Add(Me.labelParamValue)
        Me.groupBoxParamCfg.Controls.Add(Me.numericUpDownParamValue)
        Me.groupBoxParamCfg.Controls.Add(Me.buttonParamGet)
        Me.groupBoxParamCfg.Controls.Add(Me.buttonParamSet)
        Me.groupBoxParamCfg.Dock = System.Windows.Forms.DockStyle.Top
        Me.groupBoxParamCfg.Location = New System.Drawing.Point(3, 3)
        Me.groupBoxParamCfg.Name = "groupBoxParamCfg"
        Me.groupBoxParamCfg.Size = New System.Drawing.Size(870, 58)
        Me.groupBoxParamCfg.TabIndex = 0
        Me.groupBoxParamCfg.TabStop = False
        Me.groupBoxParamCfg.Text = " Configuration Parameters "
        '
        'labelParameter
        '
        Me.labelParameter.AutoSize = True
        Me.labelParameter.Location = New System.Drawing.Point(6, 16)
        Me.labelParameter.Name = "labelParameter"
        Me.labelParameter.Size = New System.Drawing.Size(58, 13)
        Me.labelParameter.TabIndex = 1
        Me.labelParameter.Text = "Parameter:"
        '
        'comboBoxParameter
        '
        Me.comboBoxParameter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxParameter.FormattingEnabled = True
        Me.comboBoxParameter.Location = New System.Drawing.Point(6, 31)
        Me.comboBoxParameter.Name = "comboBoxParameter"
        Me.comboBoxParameter.Size = New System.Drawing.Size(221, 21)
        Me.comboBoxParameter.TabIndex = 2
        '
        'labelParamActivation
        '
        Me.labelParamActivation.AutoSize = True
        Me.labelParamActivation.Location = New System.Drawing.Point(241, 11)
        Me.labelParamActivation.Name = "labelParamActivation"
        Me.labelParamActivation.Size = New System.Drawing.Size(57, 13)
        Me.labelParamActivation.TabIndex = 3
        Me.labelParamActivation.Text = "Activation:"
        '
        'radioButtonParamActive
        '
        Me.radioButtonParamActive.Checked = True
        Me.radioButtonParamActive.Location = New System.Drawing.Point(238, 32)
        Me.radioButtonParamActive.Name = "radioButtonParamActive"
        Me.radioButtonParamActive.Size = New System.Drawing.Size(56, 17)
        Me.radioButtonParamActive.TabIndex = 4
        Me.radioButtonParamActive.TabStop = True
        Me.radioButtonParamActive.Text = "Active"
        Me.radioButtonParamActive.UseVisualStyleBackColor = True
        '
        'radioButtonParamInactive
        '
        Me.radioButtonParamInactive.Location = New System.Drawing.Point(300, 32)
        Me.radioButtonParamInactive.Name = "radioButtonParamInactive"
        Me.radioButtonParamInactive.Size = New System.Drawing.Size(67, 17)
        Me.radioButtonParamInactive.TabIndex = 5
        Me.radioButtonParamInactive.Text = "Inactive"
        Me.radioButtonParamInactive.UseVisualStyleBackColor = True
        '
        'labelParamValue
        '
        Me.labelParamValue.AutoSize = True
        Me.labelParamValue.Location = New System.Drawing.Point(405, 12)
        Me.labelParamValue.Name = "labelParamValue"
        Me.labelParamValue.Size = New System.Drawing.Size(87, 13)
        Me.labelParamValue.TabIndex = 6
        Me.labelParamValue.Text = "Parameter value:"
        '
        'numericUpDownParamValue
        '
        Me.numericUpDownParamValue.Enabled = False
        Me.numericUpDownParamValue.Hexadecimal = True
        Me.numericUpDownParamValue.Location = New System.Drawing.Point(408, 29)
        Me.numericUpDownParamValue.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.numericUpDownParamValue.Name = "numericUpDownParamValue"
        Me.numericUpDownParamValue.Size = New System.Drawing.Size(99, 20)
        Me.numericUpDownParamValue.TabIndex = 7
        '
        'buttonParamGet
        '
        Me.buttonParamGet.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamGet.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamGet.Location = New System.Drawing.Point(802, 26)
        Me.buttonParamGet.Name = "buttonParamGet"
        Me.buttonParamGet.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamGet.TabIndex = 9
        Me.buttonParamGet.Text = "Get"
        Me.buttonParamGet.UseVisualStyleBackColor = True
        '
        'buttonParamSet
        '
        Me.buttonParamSet.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonParamSet.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonParamSet.Location = New System.Drawing.Point(731, 26)
        Me.buttonParamSet.Name = "buttonParamSet"
        Me.buttonParamSet.Size = New System.Drawing.Size(65, 23)
        Me.buttonParamSet.TabIndex = 8
        Me.buttonParamSet.Text = "Set"
        Me.buttonParamSet.UseVisualStyleBackColor = True
        '
        'tabControlMain
        '
        Me.tabControlMain.Controls.Add(Me.tabPageParameters)
        Me.tabControlMain.Controls.Add(Me.tabPageMappings)
        Me.tabControlMain.Controls.Add(Me.tabPageMessages)
        Me.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tabControlMain.Location = New System.Drawing.Point(0, 65)
        Me.tabControlMain.Name = "tabControlMain"
        Me.tabControlMain.SelectedIndex = 0
        Me.tabControlMain.Size = New System.Drawing.Size(884, 346)
        Me.tabControlMain.TabIndex = 46
        '
        'tabPageMappings
        '
        Me.tabPageMappings.BackColor = System.Drawing.SystemColors.Control
        Me.tabPageMappings.Controls.Add(Me.buttonMappingLoad)
        Me.tabPageMappings.Controls.Add(Me.buttonMappingSave)
        Me.tabPageMappings.Controls.Add(Me.buttonMappingSample)
        Me.tabPageMappings.Controls.Add(Me.buttonMappingDel)
        Me.tabPageMappings.Controls.Add(Me.buttonMappingAdd)
        Me.tabPageMappings.Controls.Add(Me.listViewMappings)
        Me.tabPageMappings.Location = New System.Drawing.Point(4, 22)
        Me.tabPageMappings.Name = "tabPageMappings"
        Me.tabPageMappings.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPageMappings.Size = New System.Drawing.Size(876, 320)
        Me.tabPageMappings.TabIndex = 0
        Me.tabPageMappings.Text = "Mappings"
        '
        'buttonMappingSample
        '
        Me.buttonMappingSample.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonMappingSample.Location = New System.Drawing.Point(773, 291)
        Me.buttonMappingSample.Name = "buttonMappingSample"
        Me.buttonMappingSample.Size = New System.Drawing.Size(75, 23)
        Me.buttonMappingSample.TabIndex = 3
        Me.buttonMappingSample.Text = "Fill example"
        Me.buttonMappingSample.UseVisualStyleBackColor = True
        '
        'buttonMappingDel
        '
        Me.buttonMappingDel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.buttonMappingDel.Location = New System.Drawing.Point(87, 291)
        Me.buttonMappingDel.Name = "buttonMappingDel"
        Me.buttonMappingDel.Size = New System.Drawing.Size(75, 23)
        Me.buttonMappingDel.TabIndex = 2
        Me.buttonMappingDel.Text = "Remove"
        Me.buttonMappingDel.UseVisualStyleBackColor = True
        '
        'buttonMappingAdd
        '
        Me.buttonMappingAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.buttonMappingAdd.Location = New System.Drawing.Point(6, 291)
        Me.buttonMappingAdd.Name = "buttonMappingAdd"
        Me.buttonMappingAdd.Size = New System.Drawing.Size(75, 23)
        Me.buttonMappingAdd.TabIndex = 1
        Me.buttonMappingAdd.Text = "Add"
        Me.buttonMappingAdd.UseVisualStyleBackColor = True
        '
        'listViewMappings
        '
        Me.listViewMappings.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listViewMappings.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeaderMappingCanId, Me.columnHeaderMappingCanIdResponse, Me.columnHeaderMappingTargetType, Me.columnHeaderMappingCanIdType, Me.columnHeaderMappingSourceAddr, Me.columnHeaderMappingTargetAddr, Me.columnHeaderMappingMsgType, Me.columnHeaderMappingFormat, Me.columnHeaderMappingRemoteAddr})
        Me.listViewMappings.FullRowSelect = True
        Me.listViewMappings.Location = New System.Drawing.Point(6, 6)
        Me.listViewMappings.Name = "listViewMappings"
        Me.listViewMappings.Size = New System.Drawing.Size(842, 279)
        Me.listViewMappings.TabIndex = 0
        Me.listViewMappings.UseCompatibleStateImageBehavior = False
        Me.listViewMappings.View = System.Windows.Forms.View.Details
        '
        'columnHeaderMappingCanId
        '
        Me.columnHeaderMappingCanId.Text = "CAN ID"
        Me.columnHeaderMappingCanId.Width = 100
        '
        'columnHeaderMappingCanIdResponse
        '
        Me.columnHeaderMappingCanIdResponse.Text = "CAN ID Response"
        Me.columnHeaderMappingCanIdResponse.Width = 100
        '
        'columnHeaderMappingTargetType
        '
        Me.columnHeaderMappingTargetType.Text = "Target Type"
        Me.columnHeaderMappingTargetType.Width = 70
        '
        'columnHeaderMappingCanIdType
        '
        Me.columnHeaderMappingCanIdType.Text = "ID type"
        Me.columnHeaderMappingCanIdType.Width = 50
        '
        'buttonHwRefresh
        '
        Me.buttonHwRefresh.Cursor = System.Windows.Forms.Cursors.Default
        Me.buttonHwRefresh.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonHwRefresh.Location = New System.Drawing.Point(141, 31)
        Me.buttonHwRefresh.Name = "buttonHwRefresh"
        Me.buttonHwRefresh.Size = New System.Drawing.Size(57, 23)
        Me.buttonHwRefresh.TabIndex = 45
        Me.buttonHwRefresh.Text = "Refresh"
        '
        'comboBoxChannel
        '
        Me.comboBoxChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxChannel.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboBoxChannel.Location = New System.Drawing.Point(8, 32)
        Me.comboBoxChannel.Name = "comboBoxChannel"
        Me.comboBoxChannel.Size = New System.Drawing.Size(127, 21)
        Me.comboBoxChannel.TabIndex = 32
        '
        'labelConnHardware
        '
        Me.labelConnHardware.Location = New System.Drawing.Point(7, 16)
        Me.labelConnHardware.Name = "labelConnHardware"
        Me.labelConnHardware.Size = New System.Drawing.Size(56, 23)
        Me.labelConnHardware.TabIndex = 40
        Me.labelConnHardware.Text = "Hardware:"
        '
        'buttonInit
        '
        Me.buttonInit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonInit.Cursor = System.Windows.Forms.Cursors.Default
        Me.buttonInit.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonInit.Location = New System.Drawing.Point(738, 30)
        Me.buttonInit.Name = "buttonInit"
        Me.buttonInit.Size = New System.Drawing.Size(65, 23)
        Me.buttonInit.TabIndex = 34
        Me.buttonInit.Text = "Initialize"
        '
        'buttonRelease
        '
        Me.buttonRelease.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.buttonRelease.Cursor = System.Windows.Forms.Cursors.Default
        Me.buttonRelease.Enabled = False
        Me.buttonRelease.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.buttonRelease.Location = New System.Drawing.Point(809, 30)
        Me.buttonRelease.Name = "buttonRelease"
        Me.buttonRelease.Size = New System.Drawing.Size(65, 23)
        Me.buttonRelease.TabIndex = 35
        Me.buttonRelease.Text = "Release"
        '
        'groupBoxConnection
        '
        Me.groupBoxConnection.Controls.Add(Me.checkBoxCanFd)
        Me.groupBoxConnection.Controls.Add(Me.comboBoxHwType)
        Me.groupBoxConnection.Controls.Add(Me.comboBoxInterrupt)
        Me.groupBoxConnection.Controls.Add(Me.labelConnInterrupt)
        Me.groupBoxConnection.Controls.Add(Me.comboBoxIoPort)
        Me.groupBoxConnection.Controls.Add(Me.labelConnIoPort)
        Me.groupBoxConnection.Controls.Add(Me.labelConnHwType)
        Me.groupBoxConnection.Controls.Add(Me.comboBoxBaudrate)
        Me.groupBoxConnection.Controls.Add(Me.labelConnBaudrate)
        Me.groupBoxConnection.Controls.Add(Me.buttonHwRefresh)
        Me.groupBoxConnection.Controls.Add(Me.comboBoxChannel)
        Me.groupBoxConnection.Controls.Add(Me.labelConnHardware)
        Me.groupBoxConnection.Controls.Add(Me.buttonInit)
        Me.groupBoxConnection.Controls.Add(Me.buttonRelease)
        Me.groupBoxConnection.Controls.Add(Me.textBoxCanFdBitrate)
        Me.groupBoxConnection.Controls.Add(Me.labelConnBitRate)
        Me.groupBoxConnection.Dock = System.Windows.Forms.DockStyle.Top
        Me.groupBoxConnection.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.groupBoxConnection.Location = New System.Drawing.Point(0, 0)
        Me.groupBoxConnection.Name = "groupBoxConnection"
        Me.groupBoxConnection.Size = New System.Drawing.Size(884, 65)
        Me.groupBoxConnection.TabIndex = 45
        Me.groupBoxConnection.TabStop = False
        Me.groupBoxConnection.Text = " Connection "
        '
        'timerDisplay
        '
        '
        'buttonMappingSave
        '
        Me.buttonMappingSave.Location = New System.Drawing.Point(661, 291)
        Me.buttonMappingSave.Name = "buttonMappingSave"
        Me.buttonMappingSave.Size = New System.Drawing.Size(88, 23)
        Me.buttonMappingSave.TabIndex = 4
        Me.buttonMappingSave.Text = "Save Mapping"
        Me.buttonMappingSave.UseVisualStyleBackColor = True
        '
        'buttonMappingLoad
        '
        Me.buttonMappingLoad.Location = New System.Drawing.Point(567, 291)
        Me.buttonMappingLoad.Name = "buttonMappingLoad"
        Me.buttonMappingLoad.Size = New System.Drawing.Size(88, 23)
        Me.buttonMappingLoad.TabIndex = 5
        Me.buttonMappingLoad.Text = "Load Mapping"
        Me.buttonMappingLoad.UseVisualStyleBackColor = True
        '
        'textBoxCanFdBitrate
        '
        Me.textBoxCanFdBitrate.Location = New System.Drawing.Point(204, 29)
        Me.textBoxCanFdBitrate.Multiline = True
        Me.textBoxCanFdBitrate.Name = "textBoxCanFdBitrate"
        Me.textBoxCanFdBitrate.Size = New System.Drawing.Size(461, 32)
        Me.textBoxCanFdBitrate.TabIndex = 57
        Me.textBoxCanFdBitrate.Visible = False
        '
        'labelConnBitRate
        '
        Me.labelConnBitRate.AutoSize = True
        Me.labelConnBitRate.Location = New System.Drawing.Point(205, 15)
        Me.labelConnBitRate.Name = "labelConnBitRate"
        Me.labelConnBitRate.Size = New System.Drawing.Size(43, 13)
        Me.labelConnBitRate.TabIndex = 58
        Me.labelConnBitRate.Text = "Bit rate:"
        Me.labelConnBitRate.Visible = False
        '
        'checkBoxCanFd
        '
        Me.checkBoxCanFd.AutoSize = True
        Me.checkBoxCanFd.Location = New System.Drawing.Point(670, 33)
        Me.checkBoxCanFd.Name = "checkBoxCanFd"
        Me.checkBoxCanFd.Size = New System.Drawing.Size(65, 17)
        Me.checkBoxCanFd.TabIndex = 59
        Me.checkBoxCanFd.Text = "CAN-FD"
        Me.checkBoxCanFd.UseVisualStyleBackColor = True
        '
        'checkBoxFDMessage
        '
        Me.checkBoxFDMessage.AutoSize = True
        Me.checkBoxFDMessage.Location = New System.Drawing.Point(672, 25)
        Me.checkBoxFDMessage.Name = "checkBoxFDMessage"
        Me.checkBoxFDMessage.Size = New System.Drawing.Size(40, 17)
        Me.checkBoxFDMessage.TabIndex = 14
        Me.checkBoxFDMessage.Text = "FD"
        Me.checkBoxFDMessage.UseVisualStyleBackColor = True
        '
        'checkBoxBRS
        '
        Me.checkBoxBRS.AutoSize = True
        Me.checkBoxBRS.Location = New System.Drawing.Point(672, 49)
        Me.checkBoxBRS.Name = "checkBoxBRS"
        Me.checkBoxBRS.Size = New System.Drawing.Size(48, 17)
        Me.checkBoxBRS.TabIndex = 15
        Me.checkBoxBRS.Text = "BRS"
        Me.checkBoxBRS.UseVisualStyleBackColor = True
        '
        'checkBoxHasPriority
        '
        Me.checkBoxHasPriority.AutoSize = True
        Me.checkBoxHasPriority.Enabled = False
        Me.checkBoxHasPriority.Location = New System.Drawing.Point(722, 25)
        Me.checkBoxHasPriority.Name = "checkBoxHasPriority"
        Me.checkBoxHasPriority.Size = New System.Drawing.Size(78, 17)
        Me.checkBoxHasPriority.TabIndex = 16
        Me.checkBoxHasPriority.Text = "Has priority"
        Me.checkBoxHasPriority.UseVisualStyleBackColor = True
        '
        'numericUpDownPriority
        '
        Me.numericUpDownPriority.Enabled = False
        Me.numericUpDownPriority.Location = New System.Drawing.Point(721, 48)
        Me.numericUpDownPriority.Name = "numericUpDownPriority"
        Me.numericUpDownPriority.Size = New System.Drawing.Size(77, 20)
        Me.numericUpDownPriority.TabIndex = 17
        Me.numericUpDownPriority.Value = New Decimal(New Integer() {6, 0, 0, 0})
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 411)
        Me.Controls.Add(Me.tabControlMain)
        Me.Controls.Add(Me.groupBoxConnection)
        Me.Name = "FormMain"
        Me.Text = "PCAN ISO-TP Example"
        Me.groupBoxMsgRead.ResumeLayout(False)
        Me.groupBoxMsgRead.PerformLayout()
        Me.tabPageMessages.ResumeLayout(False)
        Me.groupBoxMsgWrite.ResumeLayout(False)
        Me.groupBoxMsgWrite.PerformLayout()
        CType(Me.numericUpDownRemoteAddr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownTargetAddr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownSourceAddr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numericUpDownMsgLength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.groupBoxParamInfo.ResumeLayout(False)
        Me.tabPageParameters.ResumeLayout(False)
        Me.groupBoxParamCfg.ResumeLayout(False)
        Me.groupBoxParamCfg.PerformLayout()
        CType(Me.numericUpDownParamValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabControlMain.ResumeLayout(False)
        Me.tabPageMappings.ResumeLayout(False)
        Me.groupBoxConnection.ResumeLayout(False)
        Me.groupBoxConnection.PerformLayout()
        CType(Me.numericUpDownPriority, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents columnHeaderMappingMsgType As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgLen As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgResult As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgTargetType As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgFormat As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgType As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgIdType As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgRemoteAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgTargetAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgSourceAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents checkBoxMsgShowPeriod As System.Windows.Forms.CheckBox
    Private WithEvents radioButtonMsgManual As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonMsgEvent As System.Windows.Forms.RadioButton
    Private WithEvents listViewMsgs As System.Windows.Forms.ListView
    Private WithEvents columnHeaderMsgCount As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgTimestamp As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMsgData As System.Windows.Forms.ColumnHeader
    Private WithEvents groupBoxMsgRead As System.Windows.Forms.GroupBox
    Private WithEvents buttonMsgClear As System.Windows.Forms.Button
    Private WithEvents radioButtonMsgTimer As System.Windows.Forms.RadioButton
    Private WithEvents buttonMsgRead As System.Windows.Forms.Button
    Private WithEvents tabPageMessages As System.Windows.Forms.TabPage
    Private WithEvents groupBoxMsgWrite As System.Windows.Forms.GroupBox
    Private WithEvents numericUpDownRemoteAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents numericUpDownTargetAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents numericUpDownSourceAddr As System.Windows.Forms.NumericUpDown
    Private WithEvents buttonMsgDataFill As System.Windows.Forms.Button
    Private WithEvents labelMsgRemoteAddr As System.Windows.Forms.Label
    Private WithEvents labelMsgTargetAddr As System.Windows.Forms.Label
    Private WithEvents textBoxMsgData As System.Windows.Forms.TextBox
    Private WithEvents labelMsgMapping As System.Windows.Forms.Label
    Private WithEvents comboBoxMsgMapping As System.Windows.Forms.ComboBox
    Private WithEvents labelMsgData As System.Windows.Forms.Label
    Private WithEvents buttonMsgWrite As System.Windows.Forms.Button
    Private WithEvents labelMsgLength As System.Windows.Forms.Label
    Private WithEvents labelMsgSourceAddr As System.Windows.Forms.Label
    Private WithEvents numericUpDownMsgLength As System.Windows.Forms.NumericUpDown
    Private WithEvents columnHeaderMappingRemoteAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMappingFormat As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMappingTargetAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents timerRead As System.Windows.Forms.Timer
    Private WithEvents columnHeaderMappingSourceAddr As System.Windows.Forms.ColumnHeader
    Private WithEvents buttonParamVersion As System.Windows.Forms.Button
    Private WithEvents comboBoxHwType As System.Windows.Forms.ComboBox
    Private WithEvents comboBoxInterrupt As System.Windows.Forms.ComboBox
    Private WithEvents labelConnInterrupt As System.Windows.Forms.Label
    Private WithEvents comboBoxIoPort As System.Windows.Forms.ComboBox
    Private WithEvents labelConnIoPort As System.Windows.Forms.Label
    Private WithEvents labelConnHwType As System.Windows.Forms.Label
    Private WithEvents comboBoxBaudrate As System.Windows.Forms.ComboBox
    Private WithEvents labelConnBaudrate As System.Windows.Forms.Label
    Private WithEvents buttonParamReset As System.Windows.Forms.Button
    Private WithEvents groupBoxParamInfo As System.Windows.Forms.GroupBox
    Private WithEvents buttonParamStatus As System.Windows.Forms.Button
    Private WithEvents listBoxParamInfo As System.Windows.Forms.ListBox
    Private WithEvents buttonParamInfoClear As System.Windows.Forms.Button
    Private WithEvents tabPageParameters As System.Windows.Forms.TabPage
    Private WithEvents groupBoxParamCfg As System.Windows.Forms.GroupBox
    Private WithEvents labelParameter As System.Windows.Forms.Label
    Private WithEvents comboBoxParameter As System.Windows.Forms.ComboBox
    Private WithEvents labelParamActivation As System.Windows.Forms.Label
    Private WithEvents radioButtonParamActive As System.Windows.Forms.RadioButton
    Private WithEvents radioButtonParamInactive As System.Windows.Forms.RadioButton
    Private WithEvents labelParamValue As System.Windows.Forms.Label
    Private WithEvents numericUpDownParamValue As System.Windows.Forms.NumericUpDown
    Private WithEvents buttonParamGet As System.Windows.Forms.Button
    Private WithEvents buttonParamSet As System.Windows.Forms.Button
    Private WithEvents tabControlMain As System.Windows.Forms.TabControl
    Private WithEvents tabPageMappings As System.Windows.Forms.TabPage
    Private WithEvents buttonMappingSample As System.Windows.Forms.Button
    Private WithEvents buttonMappingDel As System.Windows.Forms.Button
    Private WithEvents buttonMappingAdd As System.Windows.Forms.Button
    Private WithEvents listViewMappings As System.Windows.Forms.ListView
    Private WithEvents columnHeaderMappingCanId As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMappingCanIdResponse As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMappingTargetType As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeaderMappingCanIdType As System.Windows.Forms.ColumnHeader
    Private WithEvents buttonHwRefresh As System.Windows.Forms.Button
    Private WithEvents comboBoxChannel As System.Windows.Forms.ComboBox
    Private WithEvents labelConnHardware As System.Windows.Forms.Label
    Private WithEvents buttonInit As System.Windows.Forms.Button
    Private WithEvents buttonRelease As System.Windows.Forms.Button
    Private WithEvents groupBoxConnection As System.Windows.Forms.GroupBox
    Private WithEvents timerDisplay As System.Windows.Forms.Timer
    Friend WithEvents buttonMappingLoad As Button
    Friend WithEvents buttonMappingSave As Button
    Friend WithEvents labelConnBitRate As Label
    Friend WithEvents textBoxCanFdBitrate As TextBox
    Friend WithEvents checkBoxCanFd As CheckBox
    Friend WithEvents checkBoxBRS As CheckBox
    Friend WithEvents checkBoxFDMessage As CheckBox
    Friend WithEvents checkBoxHasPriority As CheckBox
    Friend WithEvents numericUpDownPriority As NumericUpDown
End Class
