Contents of this directory
--------------------------
examples.sln
	Visual Studio Solution regrouping projects 01_xxx to 08_xxx.

readme.txt
    This text file.

\01_server_ISO15765-2_normal_addressing
	This project initializes a listening ISO-TP node on USB handle #2 and prints received messages.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mapping for "11 bit CAN identifier physical normal" addressing
	- read CANTP messages using events
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please use "02_client_ISO15765-2_normal_addressing" to transmit CANTP message and see them output by this executable.
	
\02_client_ISO15765-2_normal_addressing
	This project initializes a transmitting ISO-TP node on USB handle #1.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mapping for "11 bit CAN identifier physical normal" addressing
	- initialize "11 bit CAN identifier physical normal" addressing CANTP message 
	- write CANTP messages
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please launch "01_server_ISO15765-2_normal_addressing" before this executable in order to set up a listening ISO-TP node.
	
\03_server_ISO15765-2_fixed_normal_addressing
	This project initializes a listening ISO-TP node on USB handle #2 and prints received messages.
	It shows how to: 
	- initialize a CANTP channel
	- assert that "29 bit CAN identifier fixed normal" addressing is automatically handled by the API
	- read CANTP messages using events
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please use "04_client_ISO15765-2_fixed_normal_addressing" to transmit CANTP message and see them output by this executable.
	
\04_client_ISO15765-2_fixed_normal_addressing
	This project initializes a transmitting ISO-TP node on USB handle #1.
	It shows how to: 
	- initialize a CANTP channel
	- assert that "29 bit CAN identifier fixed normal" addressing is automatically handled by the API
	- initialize "29 bit CAN identifier physical fixed normal" addressing CANTP message	
	- write CANTP messages
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please launch "03_server_ISO15765-2_fixed_normal_addressing" before this executable in order to set up a listening ISO-TP node.
	
\05_isotp_read_write
	This project initializes 2 CANTP channels on USB handle #1 and #2 and start unsegmented ISO-TP communication.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mappings
	- initialize CANTP message 
	- write and read unsegmented CANTP messages
	- release CANTP messages
	- unintialize CANTP channels
	WARNING: In order to keep the sample as simple as possible, this test is designed for unsegmented ISO-TP messages only (Single Frame ISO-TP message).
		Please switch to "06_isotp_segmented_read_write" to check full segmented communication.

\06_isotp_segmented_read_write
	This project initializes 2 CANTP channels on USB handle #1 and #2 and start segmented ISO-TP communication.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mappings
	- initialize CANTP message 
	- write segmented CANTP messages
	- read the written loopback message
	- read segmented CANTP messages: indication message and completed message
	- release CANTP messages
	- unintialize CANTP channels

\07_classic_can_read_write
	This project initializes 2 CANTP channels on USB handle #1 and #2 and start classic CAN communication.
	It shows how to: 
	- initialize a CANTP channel
	- initialize CANTP message for classic CAN frame communication
	- write CAN frame
	- read CAN frame
	- release CANTP messages
	- unintialize CANTP channels

\08_canfd_read_write
	This project initializes 2 CANTP channels on USB handle #1 and #2 and start CAN-FD communication.
	It shows how to: 
	- initialize a CANTP channel
	- initialize CANTP message for CAN-FD frame communication
	- write CAN-FD frame
	- read CAN-FD frame
	- release CANTP messages
	- unintialize CANTP channels
	
\09_server_isotp
	This project is the updated 3.x version of PCAN-ISO-TP_2.x sample 'PCTPServer'. 
	It initializes a listening ISO-TP node on USB handle #2 and prints received messages.
	Some customization can be set via command-line parameters.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mappings for all ISO-TP addressings.
	- read CANTP messages using events
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please use "10_client_isotp" to transmit CANTP message and see them output by this executable.
	
\10_client_isotp
	This project is the updated 3.x version of PCAN-ISO-TP_2.x sample 'PCTPClient'. 
	It initializes a transmitting ISO-TP node on USB handle #1 and prints transmitted messages.
	Some customization can be set via command-line parameters.
	It shows how to: 
	- initialize a CANTP channel
	- configure ISO-TP mappings for all ISO-TP addressings.
	- write CANTP messages using events
	- read messages confirmations (loopback)
	- release CANTP message
	- unintialize a CANTP channel
	WARNING: please launch "09_server_isotp" before this executable in order to set up a listening ISO-TP node.
	
\PCAN-ISO-TP_2.x - backward compatibility
	This folder contains a PCAN-ISO-TP_2.x example that shows backward compatibility.
	\PcanIsoTpExample is a GUI example demonstrating all the features of PCAN-ISO-TP 2.x API.
