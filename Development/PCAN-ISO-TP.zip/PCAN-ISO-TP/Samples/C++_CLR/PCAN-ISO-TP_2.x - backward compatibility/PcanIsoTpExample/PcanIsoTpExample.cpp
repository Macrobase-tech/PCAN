// PcanIsoTpExample.cpp : main project file.

#include "stdafx.h"
#include "FormMain.h"

//#include "CANExamplesValidation-CLR.h"
//using namespace Peak::Can::Validation;

using namespace PcanIsoTpExample;


[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	
	// Enabling Windows XP visual effects before any controls are created
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false); 
	// Create the main window and run it
	Application::Run(gcnew FormMain());
	return 0;
}
