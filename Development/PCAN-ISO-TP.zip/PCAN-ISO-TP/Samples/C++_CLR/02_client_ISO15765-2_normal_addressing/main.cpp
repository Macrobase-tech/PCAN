#include "PCANBasicCLR.h" 
#include "PCAN-ISO-TP-CLR_2016.h"

using namespace System;
using namespace System::IO;
using namespace Peak::Can::IsoTp;

#define STMIN_600US 0xF6

static String^ OK_KO(bool test)
{
	if (test)
		return "OK";
	return "KO";
}

static String^ STATUS_OK_KO(cantp_status test)
{
	return OK_KO(CanTpApi::StatusIsOk_2016(test));
}

static String^ getNetStatusAsHexaString(cantp_msg msg)
{
	StringBuilder s("");
	if (msg.msgdata.any != nullptr)
		s.AppendFormat("{0:X}", (UInt32)msg.msgdata.any->netstatus);
	else
		s.Append("Unknown");

	return s.ToString();
}

/// <summary>Entry point of the program, start a small CAN ISO TP read/write example</summary>
int main(array<System::String ^> ^args)
{
	const String^ DATA_UNSEGMENTED = "PEAK";
	const String^ DATA_SEGMENTED = "PEAK-System - PCAN-ISO-TP Sample";
	// TODO: Change MSG definition to perform UNSEGMENTED or SEGMENTED ISO-TP message
	String^ MSG = (String^)DATA_SEGMENTED;

	// Local variables
	int MSG_SIZE = MSG->Length;
	cantp_status res;
	StringBuilder ^buffer = gcnew StringBuilder(500);
	UInt32 STmin;
	cantp_msg tx_msg;
	cantp_msg rx_msg;
	cantp_mapping mapping;
	cantp_handle client_handle;

	// Initialize variables
	client_handle = cantp_handle::PCANTP_HANDLE_USBBUS1;  // TODO: modify the value according to your available PCAN devices.

	// Print version informations
	CanTpApi::GetValue_2016(cantp_handle::PCANTP_HANDLE_NONEBUS, cantp_parameter::PCANTP_PARAMETER_API_VERSION, buffer, 500);
	Console::WriteLine("PCAN-ISO-TP API Version : {0}", buffer);

	// Initialize channel: CAN2.0 - 500Kbit/s
	res = CanTpApi::Initialize_2016(client_handle, cantp_baudrate::PCANTP_BAUDRATE_500K);
	Console::WriteLine("Initialize : {0}", STATUS_OK_KO(res));

	// Change STmin value to 600us
	STmin = STMIN_600US;
	res = CanTpApi::SetValue_2016(client_handle, cantp_parameter::PCANTP_PARAMETER_SEPARATION_TIME, STmin, sizeof(UInt32));
	Console::WriteLine("Set STMIN = 600us : {0}", STATUS_OK_KO(res));

	// Allocate tx message
	res = CanTpApi::MsgDataAlloc_2016(tx_msg, cantp_msgtype::PCANTP_MSGTYPE_ISOTP);
	Console::WriteLine("Allocate tx message : {0}", STATUS_OK_KO(res));

	// Create a simple physical mapping: 
	//    - Source 0xF1 (client), target 0x01 (server), CAN id 0xA1, CAN ID flow control 0xA2
	//    - Diagnostic message in a classic format
	mapping.can_id = 0xA1;
	mapping.can_id_flow_ctrl = 0xA2;
	mapping.can_msgtype = cantp_can_msgtype::PCANTP_CAN_MSGTYPE_STANDARD;
	mapping.netaddrinfo.extension_addr = 0x00;
	mapping.netaddrinfo.format = cantp_isotp_format::PCANTP_ISOTP_FORMAT_NORMAL;
	mapping.netaddrinfo.msgtype = cantp_isotp_msgtype::PCANTP_ISOTP_MSGTYPE_DIAGNOSTIC;
	mapping.netaddrinfo.source_addr = 0xF1;
	mapping.netaddrinfo.target_addr = 0x01;
	mapping.netaddrinfo.target_type = cantp_isotp_addressing::PCANTP_ISOTP_ADDRESSING_PHYSICAL;

	// Add mapping on channel
	res = CanTpApi::AddMapping_2016(client_handle, mapping);
	Console::WriteLine("Add a simple mapping : {0}", STATUS_OK_KO(res));

	if (MSG_SIZE > 7)
	{
		cantp_mapping mappingSegmented;
		// data is too big to fit in an ISO-TP "Single Frame",
		//	Communication will be segmented a mapping to receive communications from the receiver: 
		//    - Source 0x01 (server), target 0xF1 (client), CAN id 0xA2, CAN ID flow control 0xA1
		//    - Diagnostic message in a classic format
		mappingSegmented.can_id = 0xA2;
		mappingSegmented.can_id_flow_ctrl = 0xA1;
		mappingSegmented.can_msgtype = cantp_can_msgtype::PCANTP_CAN_MSGTYPE_STANDARD;
		mappingSegmented.netaddrinfo.extension_addr = 0x00;
		mappingSegmented.netaddrinfo.format = cantp_isotp_format::PCANTP_ISOTP_FORMAT_NORMAL;
		mappingSegmented.netaddrinfo.msgtype = cantp_isotp_msgtype::PCANTP_ISOTP_MSGTYPE_DIAGNOSTIC;
		mappingSegmented.netaddrinfo.source_addr = 0x01;
		mappingSegmented.netaddrinfo.target_addr = 0xF1;
		mappingSegmented.netaddrinfo.target_type = cantp_isotp_addressing::PCANTP_ISOTP_ADDRESSING_PHYSICAL;

		// Add mapping on channel
		res = CanTpApi::AddMapping_2016(client_handle, mappingSegmented);
		Console::WriteLine("Add a simple mapping : {0}", STATUS_OK_KO(res));
	}

	// Initialize Tx message containing "PEAK"
	array<Byte>^ bytes = Encoding::ASCII->GetBytes(MSG);
	res = CanTpApi::MsgDataInit_2016(tx_msg, mapping.can_id, mapping.can_msgtype, MSG_SIZE, bytes, mapping.netaddrinfo);
	Console::WriteLine("Initialize tx message : {0}", STATUS_OK_KO(res));

	// Write "PEAK" message
	res = CanTpApi::Write_2016(client_handle, tx_msg);
	Console::WriteLine("Write \"PEAK\" message : {0}", STATUS_OK_KO(res));

	// Sleep to let the transmission run
	System::Threading::Thread::Sleep(100);

	if (MSG_SIZE > 7)
	{
		// Initialize Rx message
		res = CanTpApi::MsgDataAlloc_2016(rx_msg, cantp_msgtype::PCANTP_MSGTYPE_NONE);
		Console::WriteLine("Initialize rx message : {0}", STATUS_OK_KO(res));
		// Read loopback indication ISO-TP message
		res = CanTpApi::Read_2016(client_handle, rx_msg);
		Console::WriteLine("CANTP_Read_2016 (indication) : {0}, netstatus={1}", STATUS_OK_KO(res), getNetStatusAsHexaString(rx_msg));
		// Free message space
		res = CanTpApi::MsgDataFree_2016(rx_msg);
		Console::WriteLine("Free rx message : {0}", STATUS_OK_KO(res));
		// Sleep to let the transmission complete
		System::Threading::Thread::Sleep(1000);
	}

	// Initialize Rx message
	res = CanTpApi::MsgDataAlloc_2016(rx_msg, cantp_msgtype::PCANTP_MSGTYPE_NONE);
	Console::WriteLine("Initialize rx message : {0}", STATUS_OK_KO(res));
	// Read ISO-TP message
	res = CanTpApi::Read_2016(client_handle, rx_msg);
	Console::WriteLine("CANTP_Read_2016 (complete) : {0}, netstatus={1}", STATUS_OK_KO(res), getNetStatusAsHexaString(rx_msg));
	// Free message space
	res = CanTpApi::MsgDataFree_2016(rx_msg);
	Console::WriteLine("Free rx message : {0}", STATUS_OK_KO(res));

	// Free message space
	res = CanTpApi::MsgDataFree_2016(tx_msg);
	Console::WriteLine("Free tx message : {0}", STATUS_OK_KO(res));

	// Uninitialize
	res = CanTpApi::Uninitialize_2016(client_handle);
	Console::WriteLine("Uninitialize : {0}", STATUS_OK_KO(res));

	// Exit
	Console::WriteLine("Press any key to exit...");
	Console::Read();
}


