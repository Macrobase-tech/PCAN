#pragma once
#include "resource.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "PCAN-ISO-TP.h"

// CPCanIsoTpExampleDlgParameters dialog

class CPCanIsoTpExampleDlgParameters : public CDialogEx
{
	friend class CPcanIsoTpExampleDlg;
	DECLARE_DYNAMIC(CPCanIsoTpExampleDlgParameters)
public:
	CPCanIsoTpExampleDlgParameters(TPCANTPHandle *p_pctpHandle, CWnd* pParent = NULL);   // standard constructor
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PCANISOTPEXAMPLE_TAB_PARAMETERS };
#endif

public_member:
	TPCANTPHandle *m_pctpHandle; // Handle selected on combobox Channel

public_method:
	void IncludeTextMessage(CString strMsg);
	bool isConnected();

protected_method:
	DECLARE_MESSAGE_MAP()
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	afx_msg void OnBnClickedButtonSet();
	afx_msg void OnBnClickedButtonGet();
	afx_msg void OnCbnSelchangeComboParam();
	afx_msg void OnBnClickedButtonStatus();
	afx_msg void OnBnClickedButtonReset();
	afx_msg void OnBnClickedButtonClear();
	afx_msg void OnBnClickedButtonVersion();

protected_properties:
	// Dialog Data
	CComboBox comboBoxParameter;
	CListBox listBoxParamInfo;
	CButton buttonParamInfoClear;
	CButton buttonParamGet;
	CButton buttonParamReset;
	CButton buttonParamSet;
	CButton buttonParamStatus;
	CButton buttonParamVersion;
	CButton radioButtonParamActive;
	CButton radioButtonParamInactive;
	CEdit editParamValue;
	CSpinButtonCtrl numericUpDownParamValue;
};
