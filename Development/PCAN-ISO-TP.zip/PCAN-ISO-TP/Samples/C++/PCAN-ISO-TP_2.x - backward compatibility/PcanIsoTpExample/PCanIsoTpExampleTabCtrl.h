#pragma once
#include "stdafx.h"

// CPCanIsoTpExampleTabCtrl

class CPCanIsoTpExampleTabCtrl : public CTabCtrl
{
	DECLARE_DYNAMIC(CPCanIsoTpExampleTabCtrl)
public:
	CPCanIsoTpExampleTabCtrl(TPCANTPHandle *p_pctpHandle);
	CPCanIsoTpExampleTabCtrl();

public_member:
	// Declare the number of tabs
	int m_nPageCount;
	//Array to hold the list of dialog boxes/tab pages for CTabCtrl
	int m_DialogID[3];
	//CDialog Array Variable to hold the dialogs
	CDialog *m_Dialog[3];
	CPCanIsoTpExampleDlgParameters *m_Parameters;
	CPCanIsoTpExampleDlgMappings *m_Mappings;
	CPCanIsoTpExampleDlgMessages *m_Messages;

public_method:
	//Function to Create the dialog boxes during startup
	void InitDialogs(TPCANTPHandle *p_pctpHandle);
	//Function to activate the tab dialog boxes
	void ActivateTabDialogs();

protected_method:
	DECLARE_MESSAGE_MAP()
	virtual void PostNcDestroy();
	afx_msg void OnTcnSelchange(NMHDR *pNMHDR, LRESULT *pResult);
};


