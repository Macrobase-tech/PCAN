
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers
#endif
#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions





#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // MFC support for Internet Explorer 4 Common Controls
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>             // MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcontrolbars.h>     // MFC support for ribbons and control bars


#define _CRTDBG_MAP_ALLOC  
#ifndef  _CRTDBG_MAP_ALLOC

#include <stdlib.h>  
#include <crtdbg.h>  
#ifdef _DEBUG
#define DEBUG_NEW   new( _NORMAL_BLOCK, __FILE__, __LINE__)
// Replace _NORMAL_BLOCK with _CLIENT_BLOCK if you want the
// allocations to be of _CLIENT_BLOCK type
#else
#define new DEBUG_NEW
#endif

#endif // ! _CRTDBG_MAP_ALLOC


#ifndef public_member
#define public_member public
#endif
#ifndef private_member
#define private_member private
#endif
#ifndef protected_member
#define protected_member protected
#endif
#ifndef public_method
#define public_method public
#endif
#ifndef private_method
#define private_method private
#endif
#ifndef protected_method
#define protected_method protected
#endif
#ifndef public_properties
#define public_properties public
#endif
#ifndef private_properties
#define private_properties private
#endif
#ifndef protected_properties
#define protected_properties protected
#endif


#include <vector>
#include "resource.h"
#include "PCAN-ISO-TP.h"
#include "MappingStatus.h"
#include "MessageStatus.h"
#include "PCanIsoTpUtils.h"
#include "PCanIsoTpExampleDlgAddNewMappings.h"
#include "PCanIsoTpExampleDlgMappings.h"
#include "PCanIsoTpExampleDlgMessages.h"
#include "PCanIsoTpExampleDlgParameters.h"
#include "PCanIsoTpExampleTabCtrl.h"
#include "PcanIsoTpExampleDlg.h"



#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif


