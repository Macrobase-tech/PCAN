﻿namespace PcanIsoTpExample
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBoxConnection = new System.Windows.Forms.GroupBox();
            this.checkBoxCanFd = new System.Windows.Forms.CheckBox();
            this.comboBoxHwType = new System.Windows.Forms.ComboBox();
            this.comboBoxInterrupt = new System.Windows.Forms.ComboBox();
            this.labelConnInterrupt = new System.Windows.Forms.Label();
            this.comboBoxIoPort = new System.Windows.Forms.ComboBox();
            this.labelConnIoPort = new System.Windows.Forms.Label();
            this.labelConnHwType = new System.Windows.Forms.Label();
            this.comboBoxBaudrate = new System.Windows.Forms.ComboBox();
            this.labelConnBaudrate = new System.Windows.Forms.Label();
            this.buttonHwRefresh = new System.Windows.Forms.Button();
            this.comboBoxChannel = new System.Windows.Forms.ComboBox();
            this.labelConnHardware = new System.Windows.Forms.Label();
            this.buttonInit = new System.Windows.Forms.Button();
            this.buttonRelease = new System.Windows.Forms.Button();
            this.labelConnBitRate = new System.Windows.Forms.Label();
            this.textBoxCanFdBitrate = new System.Windows.Forms.TextBox();
            this.tabControlMain = new System.Windows.Forms.TabControl();
            this.tabPageParameters = new System.Windows.Forms.TabPage();
            this.groupBoxParamInfo = new System.Windows.Forms.GroupBox();
            this.buttonParamReset = new System.Windows.Forms.Button();
            this.buttonParamStatus = new System.Windows.Forms.Button();
            this.buttonParamVersion = new System.Windows.Forms.Button();
            this.listBoxParamInfo = new System.Windows.Forms.ListBox();
            this.buttonParamInfoClear = new System.Windows.Forms.Button();
            this.groupBoxParamCfg = new System.Windows.Forms.GroupBox();
            this.labelParameter = new System.Windows.Forms.Label();
            this.comboBoxParameter = new System.Windows.Forms.ComboBox();
            this.labelParamActivation = new System.Windows.Forms.Label();
            this.radioButtonParamActive = new System.Windows.Forms.RadioButton();
            this.radioButtonParamInactive = new System.Windows.Forms.RadioButton();
            this.labelParamValue = new System.Windows.Forms.Label();
            this.numericUpDownParamValue = new System.Windows.Forms.NumericUpDown();
            this.buttonParamGet = new System.Windows.Forms.Button();
            this.buttonParamSet = new System.Windows.Forms.Button();
            this.tabPageMappings = new System.Windows.Forms.TabPage();
            this.buttonMappingLoad = new System.Windows.Forms.Button();
            this.buttonMappingSave = new System.Windows.Forms.Button();
            this.buttonMappingSample = new System.Windows.Forms.Button();
            this.buttonMappingDel = new System.Windows.Forms.Button();
            this.buttonMappingAdd = new System.Windows.Forms.Button();
            this.listViewMappings = new System.Windows.Forms.ListView();
            this.columnHeaderMappingCanId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingCanIdResponse = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingTargetType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingCanIdType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingSourceAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingTargetAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingMsgType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingFormat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMappingRemoteAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageMessages = new System.Windows.Forms.TabPage();
            this.groupBoxMsgRead = new System.Windows.Forms.GroupBox();
            this.checkBoxMsgShowPeriod = new System.Windows.Forms.CheckBox();
            this.radioButtonMsgManual = new System.Windows.Forms.RadioButton();
            this.radioButtonMsgEvent = new System.Windows.Forms.RadioButton();
            this.listViewMsgs = new System.Windows.Forms.ListView();
            this.columnHeaderMsgSourceAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgTargetAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgRemoteAddr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgIdType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgFormat = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgTargetType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgResult = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgLen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgTimestamp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMsgData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonMsgClear = new System.Windows.Forms.Button();
            this.radioButtonMsgTimer = new System.Windows.Forms.RadioButton();
            this.buttonMsgRead = new System.Windows.Forms.Button();
            this.groupBoxMsgWrite = new System.Windows.Forms.GroupBox();
            this.numericUpDownPriority = new System.Windows.Forms.NumericUpDown();
            this.checkBoxHasPriority = new System.Windows.Forms.CheckBox();
            this.checkBoxBRS = new System.Windows.Forms.CheckBox();
            this.checkBoxFDMessage = new System.Windows.Forms.CheckBox();
            this.numericUpDownRemoteAddr = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownTargetAddr = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSourceAddr = new System.Windows.Forms.NumericUpDown();
            this.buttonMsgDataFill = new System.Windows.Forms.Button();
            this.labelMsgRemoteAddr = new System.Windows.Forms.Label();
            this.labelMsgTargetAddr = new System.Windows.Forms.Label();
            this.textBoxMsgData = new System.Windows.Forms.TextBox();
            this.labelMsgMapping = new System.Windows.Forms.Label();
            this.comboBoxMsgMapping = new System.Windows.Forms.ComboBox();
            this.labelMsgData = new System.Windows.Forms.Label();
            this.buttonMsgWrite = new System.Windows.Forms.Button();
            this.labelMsgLength = new System.Windows.Forms.Label();
            this.labelMsgSourceAddr = new System.Windows.Forms.Label();
            this.numericUpDownMsgLength = new System.Windows.Forms.NumericUpDown();
            this.timerDisplay = new System.Windows.Forms.Timer(this.components);
            this.timerRead = new System.Windows.Forms.Timer(this.components);
            this.groupBoxConnection.SuspendLayout();
            this.tabControlMain.SuspendLayout();
            this.tabPageParameters.SuspendLayout();
            this.groupBoxParamInfo.SuspendLayout();
            this.groupBoxParamCfg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParamValue)).BeginInit();
            this.tabPageMappings.SuspendLayout();
            this.tabPageMessages.SuspendLayout();
            this.groupBoxMsgRead.SuspendLayout();
            this.groupBoxMsgWrite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemoteAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTargetAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSourceAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMsgLength)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxConnection
            // 
            this.groupBoxConnection.Controls.Add(this.checkBoxCanFd);
            this.groupBoxConnection.Controls.Add(this.comboBoxHwType);
            this.groupBoxConnection.Controls.Add(this.comboBoxInterrupt);
            this.groupBoxConnection.Controls.Add(this.labelConnInterrupt);
            this.groupBoxConnection.Controls.Add(this.comboBoxIoPort);
            this.groupBoxConnection.Controls.Add(this.labelConnIoPort);
            this.groupBoxConnection.Controls.Add(this.labelConnHwType);
            this.groupBoxConnection.Controls.Add(this.comboBoxBaudrate);
            this.groupBoxConnection.Controls.Add(this.labelConnBaudrate);
            this.groupBoxConnection.Controls.Add(this.buttonHwRefresh);
            this.groupBoxConnection.Controls.Add(this.comboBoxChannel);
            this.groupBoxConnection.Controls.Add(this.labelConnHardware);
            this.groupBoxConnection.Controls.Add(this.buttonInit);
            this.groupBoxConnection.Controls.Add(this.buttonRelease);
            this.groupBoxConnection.Controls.Add(this.labelConnBitRate);
            this.groupBoxConnection.Controls.Add(this.textBoxCanFdBitrate);
            this.groupBoxConnection.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxConnection.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBoxConnection.Location = new System.Drawing.Point(0, 0);
            this.groupBoxConnection.Name = "groupBoxConnection";
            this.groupBoxConnection.Size = new System.Drawing.Size(884, 65);
            this.groupBoxConnection.TabIndex = 43;
            this.groupBoxConnection.TabStop = false;
            this.groupBoxConnection.Text = " Connection ";
            // 
            // checkBoxCanFd
            // 
            this.checkBoxCanFd.AutoSize = true;
            this.checkBoxCanFd.Location = new System.Drawing.Point(671, 34);
            this.checkBoxCanFd.Name = "checkBoxCanFd";
            this.checkBoxCanFd.Size = new System.Drawing.Size(65, 17);
            this.checkBoxCanFd.TabIndex = 57;
            this.checkBoxCanFd.Text = "CAN-FD";
            this.checkBoxCanFd.UseVisualStyleBackColor = true;
            this.checkBoxCanFd.CheckedChanged += new System.EventHandler(this.checkBoxCanFd_CheckedChanged);
            // 
            // comboBoxHwType
            // 
            this.comboBoxHwType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxHwType.Items.AddRange(new object[] {
            "ISA-82C200",
            "ISA-SJA1000",
            "ISA-PHYTEC",
            "DNG-82C200",
            "DNG-82C200 EPP",
            "DNG-SJA1000",
            "DNG-SJA1000 EPP"});
            this.comboBoxHwType.Location = new System.Drawing.Point(326, 32);
            this.comboBoxHwType.Name = "comboBoxHwType";
            this.comboBoxHwType.Size = new System.Drawing.Size(120, 21);
            this.comboBoxHwType.TabIndex = 50;
            // 
            // comboBoxInterrupt
            // 
            this.comboBoxInterrupt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxInterrupt.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "7",
            "9",
            "10",
            "11",
            "12",
            "15"});
            this.comboBoxInterrupt.Location = new System.Drawing.Point(513, 32);
            this.comboBoxInterrupt.Name = "comboBoxInterrupt";
            this.comboBoxInterrupt.Size = new System.Drawing.Size(55, 21);
            this.comboBoxInterrupt.TabIndex = 52;
            // 
            // labelConnInterrupt
            // 
            this.labelConnInterrupt.Location = new System.Drawing.Point(515, 15);
            this.labelConnInterrupt.Name = "labelConnInterrupt";
            this.labelConnInterrupt.Size = new System.Drawing.Size(53, 23);
            this.labelConnInterrupt.TabIndex = 56;
            this.labelConnInterrupt.Text = "Interrupt:";
            // 
            // comboBoxIoPort
            // 
            this.comboBoxIoPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxIoPort.Items.AddRange(new object[] {
            "0100",
            "0120",
            "0140",
            "0200",
            "0220",
            "0240",
            "0260",
            "0278",
            "0280",
            "02A0",
            "02C0",
            "02E0",
            "02E8",
            "02F8",
            "0300",
            "0320",
            "0340",
            "0360",
            "0378",
            "0380",
            "03BC",
            "03E0",
            "03E8",
            "03F8"});
            this.comboBoxIoPort.Location = new System.Drawing.Point(452, 32);
            this.comboBoxIoPort.Name = "comboBoxIoPort";
            this.comboBoxIoPort.Size = new System.Drawing.Size(55, 21);
            this.comboBoxIoPort.TabIndex = 51;
            // 
            // labelConnIoPort
            // 
            this.labelConnIoPort.Location = new System.Drawing.Point(452, 15);
            this.labelConnIoPort.Name = "labelConnIoPort";
            this.labelConnIoPort.Size = new System.Drawing.Size(55, 23);
            this.labelConnIoPort.TabIndex = 55;
            this.labelConnIoPort.Text = "I/O Port:";
            // 
            // labelConnHwType
            // 
            this.labelConnHwType.Location = new System.Drawing.Point(327, 15);
            this.labelConnHwType.Name = "labelConnHwType";
            this.labelConnHwType.Size = new System.Drawing.Size(90, 23);
            this.labelConnHwType.TabIndex = 54;
            this.labelConnHwType.Text = "Hardware Type:";
            // 
            // comboBoxBaudrate
            // 
            this.comboBoxBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBaudrate.Items.AddRange(new object[] {
            "1 MBit/sec",
            "800 kBit/s",
            "500 kBit/sec",
            "250 kBit/sec",
            "125 kBit/sec",
            "100 kBit/sec",
            "95,238 kBit/s",
            "83,333 kBit/s",
            "50 kBit/sec",
            "47,619 kBit/s",
            "33,333 kBit/s",
            "20 kBit/sec",
            "10 kBit/sec",
            "5 kBit/sec"});
            this.comboBoxBaudrate.Location = new System.Drawing.Point(204, 32);
            this.comboBoxBaudrate.Name = "comboBoxBaudrate";
            this.comboBoxBaudrate.Size = new System.Drawing.Size(116, 21);
            this.comboBoxBaudrate.TabIndex = 49;
            // 
            // labelConnBaudrate
            // 
            this.labelConnBaudrate.Location = new System.Drawing.Point(204, 15);
            this.labelConnBaudrate.Name = "labelConnBaudrate";
            this.labelConnBaudrate.Size = new System.Drawing.Size(56, 23);
            this.labelConnBaudrate.TabIndex = 53;
            this.labelConnBaudrate.Text = "Baudrate:";
            // 
            // buttonHwRefresh
            // 
            this.buttonHwRefresh.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonHwRefresh.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonHwRefresh.Location = new System.Drawing.Point(141, 31);
            this.buttonHwRefresh.Name = "buttonHwRefresh";
            this.buttonHwRefresh.Size = new System.Drawing.Size(57, 23);
            this.buttonHwRefresh.TabIndex = 45;
            this.buttonHwRefresh.Text = "Refresh";
            this.buttonHwRefresh.Click += new System.EventHandler(this.buttonHwRefresh_Click);
            // 
            // comboBoxChannel
            // 
            this.comboBoxChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxChannel.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxChannel.Location = new System.Drawing.Point(8, 32);
            this.comboBoxChannel.Name = "comboBoxChannel";
            this.comboBoxChannel.Size = new System.Drawing.Size(127, 21);
            this.comboBoxChannel.TabIndex = 32;
            this.comboBoxChannel.SelectedIndexChanged += new System.EventHandler(this.comboBoxChannel_SelectedIndexChanged);
            // 
            // labelConnHardware
            // 
            this.labelConnHardware.Location = new System.Drawing.Point(7, 16);
            this.labelConnHardware.Name = "labelConnHardware";
            this.labelConnHardware.Size = new System.Drawing.Size(56, 23);
            this.labelConnHardware.TabIndex = 40;
            this.labelConnHardware.Text = "Hardware:";
            // 
            // buttonInit
            // 
            this.buttonInit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonInit.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonInit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonInit.Location = new System.Drawing.Point(738, 30);
            this.buttonInit.Name = "buttonInit";
            this.buttonInit.Size = new System.Drawing.Size(65, 23);
            this.buttonInit.TabIndex = 34;
            this.buttonInit.Text = "Initialize";
            this.buttonInit.Click += new System.EventHandler(this.buttonInit_Click);
            // 
            // buttonRelease
            // 
            this.buttonRelease.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRelease.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonRelease.Enabled = false;
            this.buttonRelease.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonRelease.Location = new System.Drawing.Point(809, 30);
            this.buttonRelease.Name = "buttonRelease";
            this.buttonRelease.Size = new System.Drawing.Size(65, 23);
            this.buttonRelease.TabIndex = 35;
            this.buttonRelease.Text = "Release";
            this.buttonRelease.Click += new System.EventHandler(this.buttonRelease_Click);
            // 
            // labelConnBitRate
            // 
            this.labelConnBitRate.Location = new System.Drawing.Point(204, 15);
            this.labelConnBitRate.Name = "labelConnBitRate";
            this.labelConnBitRate.Size = new System.Drawing.Size(56, 14);
            this.labelConnBitRate.TabIndex = 59;
            this.labelConnBitRate.Text = "Bit rate:";
            this.labelConnBitRate.Visible = false;
            // 
            // textBoxCanFdBitrate
            // 
            this.textBoxCanFdBitrate.Location = new System.Drawing.Point(204, 29);
            this.textBoxCanFdBitrate.Multiline = true;
            this.textBoxCanFdBitrate.Name = "textBoxCanFdBitrate";
            this.textBoxCanFdBitrate.Size = new System.Drawing.Size(462, 32);
            this.textBoxCanFdBitrate.TabIndex = 58;
            this.textBoxCanFdBitrate.Visible = false;
            // 
            // tabControlMain
            // 
            this.tabControlMain.Controls.Add(this.tabPageParameters);
            this.tabControlMain.Controls.Add(this.tabPageMappings);
            this.tabControlMain.Controls.Add(this.tabPageMessages);
            this.tabControlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlMain.Location = new System.Drawing.Point(0, 65);
            this.tabControlMain.Name = "tabControlMain";
            this.tabControlMain.SelectedIndex = 0;
            this.tabControlMain.Size = new System.Drawing.Size(884, 346);
            this.tabControlMain.TabIndex = 44;
            // 
            // tabPageParameters
            // 
            this.tabPageParameters.Controls.Add(this.groupBoxParamInfo);
            this.tabPageParameters.Controls.Add(this.groupBoxParamCfg);
            this.tabPageParameters.Location = new System.Drawing.Point(4, 22);
            this.tabPageParameters.Name = "tabPageParameters";
            this.tabPageParameters.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageParameters.Size = new System.Drawing.Size(876, 320);
            this.tabPageParameters.TabIndex = 3;
            this.tabPageParameters.Text = "Parameters";
            this.tabPageParameters.UseVisualStyleBackColor = true;
            // 
            // groupBoxParamInfo
            // 
            this.groupBoxParamInfo.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxParamInfo.Controls.Add(this.buttonParamReset);
            this.groupBoxParamInfo.Controls.Add(this.buttonParamStatus);
            this.groupBoxParamInfo.Controls.Add(this.buttonParamVersion);
            this.groupBoxParamInfo.Controls.Add(this.listBoxParamInfo);
            this.groupBoxParamInfo.Controls.Add(this.buttonParamInfoClear);
            this.groupBoxParamInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxParamInfo.Location = new System.Drawing.Point(3, 61);
            this.groupBoxParamInfo.Name = "groupBoxParamInfo";
            this.groupBoxParamInfo.Size = new System.Drawing.Size(870, 256);
            this.groupBoxParamInfo.TabIndex = 10;
            this.groupBoxParamInfo.TabStop = false;
            this.groupBoxParamInfo.Text = "Information";
            // 
            // buttonParamReset
            // 
            this.buttonParamReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamReset.Enabled = false;
            this.buttonParamReset.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamReset.Location = new System.Drawing.Point(802, 48);
            this.buttonParamReset.Name = "buttonParamReset";
            this.buttonParamReset.Size = new System.Drawing.Size(65, 23);
            this.buttonParamReset.TabIndex = 15;
            this.buttonParamReset.Text = "Reset";
            this.buttonParamReset.UseVisualStyleBackColor = true;
            this.buttonParamReset.Click += new System.EventHandler(this.buttonParamReset_Click);
            // 
            // buttonParamStatus
            // 
            this.buttonParamStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamStatus.Location = new System.Drawing.Point(731, 48);
            this.buttonParamStatus.Name = "buttonParamStatus";
            this.buttonParamStatus.Size = new System.Drawing.Size(65, 23);
            this.buttonParamStatus.TabIndex = 14;
            this.buttonParamStatus.Text = "Status";
            this.buttonParamStatus.UseVisualStyleBackColor = true;
            this.buttonParamStatus.Click += new System.EventHandler(this.buttonParamStatus_Click);
            // 
            // buttonParamVersion
            // 
            this.buttonParamVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamVersion.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamVersion.Location = new System.Drawing.Point(731, 19);
            this.buttonParamVersion.Name = "buttonParamVersion";
            this.buttonParamVersion.Size = new System.Drawing.Size(65, 23);
            this.buttonParamVersion.TabIndex = 12;
            this.buttonParamVersion.Text = "Version";
            this.buttonParamVersion.UseVisualStyleBackColor = true;
            this.buttonParamVersion.Click += new System.EventHandler(this.buttonParamVersion_Click);
            // 
            // listBoxParamInfo
            // 
            this.listBoxParamInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBoxParamInfo.FormattingEnabled = true;
            this.listBoxParamInfo.Items.AddRange(new object[] {
            "Select a Hardware and a configuration for it. Then click \"Initialize\" button",
            "When activated, configure ISO-TP mappings in order to transmit and receive ISO-TP" +
                " messages.",
            "---",
            "Note that to successfully transmit ISO-TP messages, you need a valid ISO-TP node " +
                "to communicate with.",
            "You can run a second instance of this application on another channel to do so.",
            "---"});
            this.listBoxParamInfo.Location = new System.Drawing.Point(6, 19);
            this.listBoxParamInfo.Name = "listBoxParamInfo";
            this.listBoxParamInfo.ScrollAlwaysVisible = true;
            this.listBoxParamInfo.Size = new System.Drawing.Size(716, 225);
            this.listBoxParamInfo.TabIndex = 11;
            // 
            // buttonParamInfoClear
            // 
            this.buttonParamInfoClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamInfoClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamInfoClear.Location = new System.Drawing.Point(802, 19);
            this.buttonParamInfoClear.Name = "buttonParamInfoClear";
            this.buttonParamInfoClear.Size = new System.Drawing.Size(65, 23);
            this.buttonParamInfoClear.TabIndex = 13;
            this.buttonParamInfoClear.Text = "Clear";
            this.buttonParamInfoClear.UseVisualStyleBackColor = true;
            this.buttonParamInfoClear.Click += new System.EventHandler(this.buttonParamInfoClear_Click);
            // 
            // groupBoxParamCfg
            // 
            this.groupBoxParamCfg.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxParamCfg.Controls.Add(this.labelParameter);
            this.groupBoxParamCfg.Controls.Add(this.comboBoxParameter);
            this.groupBoxParamCfg.Controls.Add(this.labelParamActivation);
            this.groupBoxParamCfg.Controls.Add(this.radioButtonParamActive);
            this.groupBoxParamCfg.Controls.Add(this.radioButtonParamInactive);
            this.groupBoxParamCfg.Controls.Add(this.labelParamValue);
            this.groupBoxParamCfg.Controls.Add(this.numericUpDownParamValue);
            this.groupBoxParamCfg.Controls.Add(this.buttonParamGet);
            this.groupBoxParamCfg.Controls.Add(this.buttonParamSet);
            this.groupBoxParamCfg.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxParamCfg.Location = new System.Drawing.Point(3, 3);
            this.groupBoxParamCfg.Name = "groupBoxParamCfg";
            this.groupBoxParamCfg.Size = new System.Drawing.Size(870, 58);
            this.groupBoxParamCfg.TabIndex = 0;
            this.groupBoxParamCfg.TabStop = false;
            this.groupBoxParamCfg.Text = " Configuration Parameters ";
            // 
            // labelParameter
            // 
            this.labelParameter.AutoSize = true;
            this.labelParameter.Location = new System.Drawing.Point(6, 16);
            this.labelParameter.Name = "labelParameter";
            this.labelParameter.Size = new System.Drawing.Size(58, 13);
            this.labelParameter.TabIndex = 1;
            this.labelParameter.Text = "Parameter:";
            // 
            // comboBoxParameter
            // 
            this.comboBoxParameter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxParameter.FormattingEnabled = true;
            this.comboBoxParameter.Location = new System.Drawing.Point(6, 31);
            this.comboBoxParameter.Name = "comboBoxParameter";
            this.comboBoxParameter.Size = new System.Drawing.Size(221, 21);
            this.comboBoxParameter.TabIndex = 2;
            this.comboBoxParameter.SelectedIndexChanged += new System.EventHandler(this.comboBoxParameter_SelectedIndexChanged);
            // 
            // labelParamActivation
            // 
            this.labelParamActivation.AutoSize = true;
            this.labelParamActivation.Location = new System.Drawing.Point(241, 11);
            this.labelParamActivation.Name = "labelParamActivation";
            this.labelParamActivation.Size = new System.Drawing.Size(57, 13);
            this.labelParamActivation.TabIndex = 3;
            this.labelParamActivation.Text = "Activation:";
            // 
            // radioButtonParamActive
            // 
            this.radioButtonParamActive.Checked = true;
            this.radioButtonParamActive.Location = new System.Drawing.Point(238, 32);
            this.radioButtonParamActive.Name = "radioButtonParamActive";
            this.radioButtonParamActive.Size = new System.Drawing.Size(56, 17);
            this.radioButtonParamActive.TabIndex = 4;
            this.radioButtonParamActive.TabStop = true;
            this.radioButtonParamActive.Text = "Active";
            this.radioButtonParamActive.UseVisualStyleBackColor = true;
            // 
            // radioButtonParamInactive
            // 
            this.radioButtonParamInactive.Location = new System.Drawing.Point(300, 32);
            this.radioButtonParamInactive.Name = "radioButtonParamInactive";
            this.radioButtonParamInactive.Size = new System.Drawing.Size(67, 17);
            this.radioButtonParamInactive.TabIndex = 5;
            this.radioButtonParamInactive.Text = "Inactive";
            this.radioButtonParamInactive.UseVisualStyleBackColor = true;
            // 
            // labelParamValue
            // 
            this.labelParamValue.AutoSize = true;
            this.labelParamValue.Location = new System.Drawing.Point(405, 12);
            this.labelParamValue.Name = "labelParamValue";
            this.labelParamValue.Size = new System.Drawing.Size(87, 13);
            this.labelParamValue.TabIndex = 6;
            this.labelParamValue.Text = "Parameter value:";
            // 
            // numericUpDownParamValue
            // 
            this.numericUpDownParamValue.Enabled = false;
            this.numericUpDownParamValue.Hexadecimal = true;
            this.numericUpDownParamValue.Location = new System.Drawing.Point(408, 29);
            this.numericUpDownParamValue.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownParamValue.Name = "numericUpDownParamValue";
            this.numericUpDownParamValue.Size = new System.Drawing.Size(99, 20);
            this.numericUpDownParamValue.TabIndex = 7;
            // 
            // buttonParamGet
            // 
            this.buttonParamGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamGet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamGet.Location = new System.Drawing.Point(802, 26);
            this.buttonParamGet.Name = "buttonParamGet";
            this.buttonParamGet.Size = new System.Drawing.Size(65, 23);
            this.buttonParamGet.TabIndex = 9;
            this.buttonParamGet.Text = "Get";
            this.buttonParamGet.UseVisualStyleBackColor = true;
            this.buttonParamGet.Click += new System.EventHandler(this.buttonParamGet_Click);
            // 
            // buttonParamSet
            // 
            this.buttonParamSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonParamSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonParamSet.Location = new System.Drawing.Point(731, 26);
            this.buttonParamSet.Name = "buttonParamSet";
            this.buttonParamSet.Size = new System.Drawing.Size(65, 23);
            this.buttonParamSet.TabIndex = 8;
            this.buttonParamSet.Text = "Set";
            this.buttonParamSet.UseVisualStyleBackColor = true;
            this.buttonParamSet.Click += new System.EventHandler(this.buttonParamSet_Click);
            // 
            // tabPageMappings
            // 
            this.tabPageMappings.BackColor = System.Drawing.SystemColors.Control;
            this.tabPageMappings.Controls.Add(this.buttonMappingLoad);
            this.tabPageMappings.Controls.Add(this.buttonMappingSave);
            this.tabPageMappings.Controls.Add(this.buttonMappingSample);
            this.tabPageMappings.Controls.Add(this.buttonMappingDel);
            this.tabPageMappings.Controls.Add(this.buttonMappingAdd);
            this.tabPageMappings.Controls.Add(this.listViewMappings);
            this.tabPageMappings.Location = new System.Drawing.Point(4, 22);
            this.tabPageMappings.Name = "tabPageMappings";
            this.tabPageMappings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageMappings.Size = new System.Drawing.Size(876, 320);
            this.tabPageMappings.TabIndex = 0;
            this.tabPageMappings.Text = "Mappings";
            // 
            // buttonMappingLoad
            // 
            this.buttonMappingLoad.Location = new System.Drawing.Point(574, 291);
            this.buttonMappingLoad.Name = "buttonMappingLoad";
            this.buttonMappingLoad.Size = new System.Drawing.Size(88, 23);
            this.buttonMappingLoad.TabIndex = 5;
            this.buttonMappingLoad.Text = "Load Mappings";
            this.buttonMappingLoad.UseVisualStyleBackColor = true;
            this.buttonMappingLoad.Click += new System.EventHandler(this.buttonMappingLoad_Click);
            // 
            // buttonMappingSave
            // 
            this.buttonMappingSave.Location = new System.Drawing.Point(668, 291);
            this.buttonMappingSave.Name = "buttonMappingSave";
            this.buttonMappingSave.Size = new System.Drawing.Size(87, 23);
            this.buttonMappingSave.TabIndex = 4;
            this.buttonMappingSave.Text = "Save Mapping";
            this.buttonMappingSave.UseVisualStyleBackColor = true;
            this.buttonMappingSave.Click += new System.EventHandler(this.buttonMappingSave_Click);
            // 
            // buttonMappingSample
            // 
            this.buttonMappingSample.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMappingSample.Location = new System.Drawing.Point(773, 291);
            this.buttonMappingSample.Name = "buttonMappingSample";
            this.buttonMappingSample.Size = new System.Drawing.Size(75, 23);
            this.buttonMappingSample.TabIndex = 3;
            this.buttonMappingSample.Text = "Fill example";
            this.buttonMappingSample.UseVisualStyleBackColor = true;
            this.buttonMappingSample.Click += new System.EventHandler(this.buttonMappingSample_Click);
            // 
            // buttonMappingDel
            // 
            this.buttonMappingDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMappingDel.Location = new System.Drawing.Point(87, 291);
            this.buttonMappingDel.Name = "buttonMappingDel";
            this.buttonMappingDel.Size = new System.Drawing.Size(75, 23);
            this.buttonMappingDel.TabIndex = 2;
            this.buttonMappingDel.Text = "Remove";
            this.buttonMappingDel.UseVisualStyleBackColor = true;
            this.buttonMappingDel.Click += new System.EventHandler(this.buttonMappingDel_Click);
            // 
            // buttonMappingAdd
            // 
            this.buttonMappingAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonMappingAdd.Location = new System.Drawing.Point(6, 291);
            this.buttonMappingAdd.Name = "buttonMappingAdd";
            this.buttonMappingAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonMappingAdd.TabIndex = 1;
            this.buttonMappingAdd.Text = "Add";
            this.buttonMappingAdd.UseVisualStyleBackColor = true;
            this.buttonMappingAdd.Click += new System.EventHandler(this.buttonMappingAdd_Click);
            // 
            // listViewMappings
            // 
            this.listViewMappings.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewMappings.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderMappingCanId,
            this.columnHeaderMappingCanIdResponse,
            this.columnHeaderMappingTargetType,
            this.columnHeaderMappingCanIdType,
            this.columnHeaderMappingSourceAddr,
            this.columnHeaderMappingTargetAddr,
            this.columnHeaderMappingMsgType,
            this.columnHeaderMappingFormat,
            this.columnHeaderMappingRemoteAddr});
            this.listViewMappings.FullRowSelect = true;
            this.listViewMappings.Location = new System.Drawing.Point(6, 6);
            this.listViewMappings.Name = "listViewMappings";
            this.listViewMappings.Size = new System.Drawing.Size(842, 279);
            this.listViewMappings.TabIndex = 0;
            this.listViewMappings.UseCompatibleStateImageBehavior = false;
            this.listViewMappings.View = System.Windows.Forms.View.Details;
            this.listViewMappings.SelectedIndexChanged += new System.EventHandler(this.listViewMappings_SelectedIndexChanged);
            // 
            // columnHeaderMappingCanId
            // 
            this.columnHeaderMappingCanId.Text = "CAN ID";
            this.columnHeaderMappingCanId.Width = 100;
            // 
            // columnHeaderMappingCanIdResponse
            // 
            this.columnHeaderMappingCanIdResponse.Text = "CAN ID Response";
            this.columnHeaderMappingCanIdResponse.Width = 100;
            // 
            // columnHeaderMappingTargetType
            // 
            this.columnHeaderMappingTargetType.Text = "Target Type";
            this.columnHeaderMappingTargetType.Width = 70;
            // 
            // columnHeaderMappingCanIdType
            // 
            this.columnHeaderMappingCanIdType.Text = "ID type";
            this.columnHeaderMappingCanIdType.Width = 50;
            // 
            // columnHeaderMappingSourceAddr
            // 
            this.columnHeaderMappingSourceAddr.Text = "SA";
            this.columnHeaderMappingSourceAddr.Width = 50;
            // 
            // columnHeaderMappingTargetAddr
            // 
            this.columnHeaderMappingTargetAddr.Text = "TA";
            this.columnHeaderMappingTargetAddr.Width = 50;
            // 
            // columnHeaderMappingMsgType
            // 
            this.columnHeaderMappingMsgType.Text = "MsgType";
            this.columnHeaderMappingMsgType.Width = 100;
            // 
            // columnHeaderMappingFormat
            // 
            this.columnHeaderMappingFormat.Text = "Format";
            this.columnHeaderMappingFormat.Width = 100;
            // 
            // columnHeaderMappingRemoteAddr
            // 
            this.columnHeaderMappingRemoteAddr.Text = "RA";
            this.columnHeaderMappingRemoteAddr.Width = 50;
            // 
            // tabPageMessages
            // 
            this.tabPageMessages.Controls.Add(this.groupBoxMsgRead);
            this.tabPageMessages.Controls.Add(this.groupBoxMsgWrite);
            this.tabPageMessages.Location = new System.Drawing.Point(4, 22);
            this.tabPageMessages.Name = "tabPageMessages";
            this.tabPageMessages.Size = new System.Drawing.Size(876, 320);
            this.tabPageMessages.TabIndex = 2;
            this.tabPageMessages.Text = "Messages";
            this.tabPageMessages.UseVisualStyleBackColor = true;
            // 
            // groupBoxMsgRead
            // 
            this.groupBoxMsgRead.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxMsgRead.Controls.Add(this.checkBoxMsgShowPeriod);
            this.groupBoxMsgRead.Controls.Add(this.radioButtonMsgManual);
            this.groupBoxMsgRead.Controls.Add(this.radioButtonMsgEvent);
            this.groupBoxMsgRead.Controls.Add(this.listViewMsgs);
            this.groupBoxMsgRead.Controls.Add(this.buttonMsgClear);
            this.groupBoxMsgRead.Controls.Add(this.radioButtonMsgTimer);
            this.groupBoxMsgRead.Controls.Add(this.buttonMsgRead);
            this.groupBoxMsgRead.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxMsgRead.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMsgRead.Name = "groupBoxMsgRead";
            this.groupBoxMsgRead.Size = new System.Drawing.Size(876, 171);
            this.groupBoxMsgRead.TabIndex = 0;
            this.groupBoxMsgRead.TabStop = false;
            this.groupBoxMsgRead.Text = " Messages Reading ";
            // 
            // checkBoxMsgShowPeriod
            // 
            this.checkBoxMsgShowPeriod.AutoSize = true;
            this.checkBoxMsgShowPeriod.Checked = true;
            this.checkBoxMsgShowPeriod.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxMsgShowPeriod.Location = new System.Drawing.Point(374, 15);
            this.checkBoxMsgShowPeriod.Name = "checkBoxMsgShowPeriod";
            this.checkBoxMsgShowPeriod.Size = new System.Drawing.Size(123, 17);
            this.checkBoxMsgShowPeriod.TabIndex = 3;
            this.checkBoxMsgShowPeriod.Text = "Timestamp as period";
            this.checkBoxMsgShowPeriod.UseVisualStyleBackColor = true;
            this.checkBoxMsgShowPeriod.CheckedChanged += new System.EventHandler(this.checkBoxMsgShowPeriod_CheckedChanged);
            // 
            // radioButtonMsgManual
            // 
            this.radioButtonMsgManual.AutoSize = true;
            this.radioButtonMsgManual.Location = new System.Drawing.Point(276, 14);
            this.radioButtonMsgManual.Name = "radioButtonMsgManual";
            this.radioButtonMsgManual.Size = new System.Drawing.Size(89, 17);
            this.radioButtonMsgManual.TabIndex = 2;
            this.radioButtonMsgManual.Text = "Manual Read";
            this.radioButtonMsgManual.UseVisualStyleBackColor = true;
            this.radioButtonMsgManual.CheckedChanged += new System.EventHandler(this.radioButtonMsgRead_CheckedChanged);
            // 
            // radioButtonMsgEvent
            // 
            this.radioButtonMsgEvent.AutoSize = true;
            this.radioButtonMsgEvent.Location = new System.Drawing.Point(131, 14);
            this.radioButtonMsgEvent.Name = "radioButtonMsgEvent";
            this.radioButtonMsgEvent.Size = new System.Drawing.Size(139, 17);
            this.radioButtonMsgEvent.TabIndex = 1;
            this.radioButtonMsgEvent.Text = "Reading using an Event";
            this.radioButtonMsgEvent.UseVisualStyleBackColor = true;
            this.radioButtonMsgEvent.CheckedChanged += new System.EventHandler(this.radioButtonMsgRead_CheckedChanged);
            // 
            // listViewMsgs
            // 
            this.listViewMsgs.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewMsgs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderMsgSourceAddr,
            this.columnHeaderMsgTargetAddr,
            this.columnHeaderMsgRemoteAddr,
            this.columnHeaderMsgIdType,
            this.columnHeaderMsgType,
            this.columnHeaderMsgFormat,
            this.columnHeaderMsgTargetType,
            this.columnHeaderMsgResult,
            this.columnHeaderMsgLen,
            this.columnHeaderMsgCount,
            this.columnHeaderMsgTimestamp,
            this.columnHeaderMsgData});
            this.listViewMsgs.FullRowSelect = true;
            this.listViewMsgs.Location = new System.Drawing.Point(6, 37);
            this.listViewMsgs.MultiSelect = false;
            this.listViewMsgs.Name = "listViewMsgs";
            this.listViewMsgs.Size = new System.Drawing.Size(791, 128);
            this.listViewMsgs.TabIndex = 4;
            this.listViewMsgs.UseCompatibleStateImageBehavior = false;
            this.listViewMsgs.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderMsgSourceAddr
            // 
            this.columnHeaderMsgSourceAddr.Text = "Source";
            this.columnHeaderMsgSourceAddr.Width = 50;
            // 
            // columnHeaderMsgTargetAddr
            // 
            this.columnHeaderMsgTargetAddr.Text = "Target";
            this.columnHeaderMsgTargetAddr.Width = 45;
            // 
            // columnHeaderMsgRemoteAddr
            // 
            this.columnHeaderMsgRemoteAddr.Text = "Remote";
            this.columnHeaderMsgRemoteAddr.Width = 50;
            // 
            // columnHeaderMsgIdType
            // 
            this.columnHeaderMsgIdType.Text = "ID";
            this.columnHeaderMsgIdType.Width = 45;
            // 
            // columnHeaderMsgType
            // 
            this.columnHeaderMsgType.Text = "Type";
            this.columnHeaderMsgType.Width = 72;
            // 
            // columnHeaderMsgFormat
            // 
            this.columnHeaderMsgFormat.Text = "Format";
            this.columnHeaderMsgFormat.Width = 63;
            // 
            // columnHeaderMsgTargetType
            // 
            this.columnHeaderMsgTargetType.Text = "Target type";
            this.columnHeaderMsgTargetType.Width = 70;
            // 
            // columnHeaderMsgResult
            // 
            this.columnHeaderMsgResult.Text = "Result";
            this.columnHeaderMsgResult.Width = 42;
            // 
            // columnHeaderMsgLen
            // 
            this.columnHeaderMsgLen.Text = "Length";
            this.columnHeaderMsgLen.Width = 45;
            // 
            // columnHeaderMsgCount
            // 
            this.columnHeaderMsgCount.Text = "Count";
            this.columnHeaderMsgCount.Width = 50;
            // 
            // columnHeaderMsgTimestamp
            // 
            this.columnHeaderMsgTimestamp.Text = "Timestamp";
            this.columnHeaderMsgTimestamp.Width = 64;
            // 
            // columnHeaderMsgData
            // 
            this.columnHeaderMsgData.Text = "Data";
            this.columnHeaderMsgData.Width = 181;
            // 
            // buttonMsgClear
            // 
            this.buttonMsgClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMsgClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonMsgClear.Location = new System.Drawing.Point(805, 66);
            this.buttonMsgClear.Name = "buttonMsgClear";
            this.buttonMsgClear.Size = new System.Drawing.Size(65, 23);
            this.buttonMsgClear.TabIndex = 6;
            this.buttonMsgClear.Text = "Clear";
            this.buttonMsgClear.UseVisualStyleBackColor = true;
            this.buttonMsgClear.Click += new System.EventHandler(this.buttonMsgClear_Click);
            // 
            // radioButtonMsgTimer
            // 
            this.radioButtonMsgTimer.AutoSize = true;
            this.radioButtonMsgTimer.Checked = true;
            this.radioButtonMsgTimer.Location = new System.Drawing.Point(8, 14);
            this.radioButtonMsgTimer.Name = "radioButtonMsgTimer";
            this.radioButtonMsgTimer.Size = new System.Drawing.Size(117, 17);
            this.radioButtonMsgTimer.TabIndex = 0;
            this.radioButtonMsgTimer.TabStop = true;
            this.radioButtonMsgTimer.Text = "Read using a Timer";
            this.radioButtonMsgTimer.UseVisualStyleBackColor = true;
            this.radioButtonMsgTimer.CheckedChanged += new System.EventHandler(this.radioButtonMsgRead_CheckedChanged);
            // 
            // buttonMsgRead
            // 
            this.buttonMsgRead.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMsgRead.Enabled = false;
            this.buttonMsgRead.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonMsgRead.Location = new System.Drawing.Point(805, 37);
            this.buttonMsgRead.Name = "buttonMsgRead";
            this.buttonMsgRead.Size = new System.Drawing.Size(65, 23);
            this.buttonMsgRead.TabIndex = 5;
            this.buttonMsgRead.Text = "Read";
            this.buttonMsgRead.UseVisualStyleBackColor = true;
            this.buttonMsgRead.Click += new System.EventHandler(this.buttonMsgRead_Click);
            // 
            // groupBoxMsgWrite
            // 
            this.groupBoxMsgWrite.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxMsgWrite.Controls.Add(this.numericUpDownPriority);
            this.groupBoxMsgWrite.Controls.Add(this.checkBoxHasPriority);
            this.groupBoxMsgWrite.Controls.Add(this.checkBoxBRS);
            this.groupBoxMsgWrite.Controls.Add(this.checkBoxFDMessage);
            this.groupBoxMsgWrite.Controls.Add(this.numericUpDownRemoteAddr);
            this.groupBoxMsgWrite.Controls.Add(this.numericUpDownTargetAddr);
            this.groupBoxMsgWrite.Controls.Add(this.numericUpDownSourceAddr);
            this.groupBoxMsgWrite.Controls.Add(this.buttonMsgDataFill);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgRemoteAddr);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgTargetAddr);
            this.groupBoxMsgWrite.Controls.Add(this.textBoxMsgData);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgMapping);
            this.groupBoxMsgWrite.Controls.Add(this.comboBoxMsgMapping);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgData);
            this.groupBoxMsgWrite.Controls.Add(this.buttonMsgWrite);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgLength);
            this.groupBoxMsgWrite.Controls.Add(this.labelMsgSourceAddr);
            this.groupBoxMsgWrite.Controls.Add(this.numericUpDownMsgLength);
            this.groupBoxMsgWrite.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBoxMsgWrite.Location = new System.Drawing.Point(0, 171);
            this.groupBoxMsgWrite.Name = "groupBoxMsgWrite";
            this.groupBoxMsgWrite.Size = new System.Drawing.Size(876, 149);
            this.groupBoxMsgWrite.TabIndex = 1;
            this.groupBoxMsgWrite.TabStop = false;
            this.groupBoxMsgWrite.Text = "Write Messages";
            // 
            // numericUpDownPriority
            // 
            this.numericUpDownPriority.Enabled = false;
            this.numericUpDownPriority.Location = new System.Drawing.Point(725, 52);
            this.numericUpDownPriority.Maximum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.numericUpDownPriority.Name = "numericUpDownPriority";
            this.numericUpDownPriority.Size = new System.Drawing.Size(73, 20);
            this.numericUpDownPriority.TabIndex = 17;
            this.numericUpDownPriority.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // checkBoxHasPriority
            // 
            this.checkBoxHasPriority.AutoSize = true;
            this.checkBoxHasPriority.Enabled = false;
            this.checkBoxHasPriority.Location = new System.Drawing.Point(725, 28);
            this.checkBoxHasPriority.Name = "checkBoxHasPriority";
            this.checkBoxHasPriority.Size = new System.Drawing.Size(78, 17);
            this.checkBoxHasPriority.TabIndex = 16;
            this.checkBoxHasPriority.Text = "Has priority";
            this.checkBoxHasPriority.UseVisualStyleBackColor = true;
            this.checkBoxHasPriority.CheckedChanged += new System.EventHandler(this.checkBoxHasPriority_CheckedChanged);
            // 
            // checkBoxBRS
            // 
            this.checkBoxBRS.AutoSize = true;
            this.checkBoxBRS.Enabled = false;
            this.checkBoxBRS.Location = new System.Drawing.Point(674, 52);
            this.checkBoxBRS.Name = "checkBoxBRS";
            this.checkBoxBRS.Size = new System.Drawing.Size(48, 17);
            this.checkBoxBRS.TabIndex = 15;
            this.checkBoxBRS.Text = "BRS";
            this.checkBoxBRS.UseVisualStyleBackColor = true;
            this.checkBoxBRS.Visible = false;
            // 
            // checkBoxFDMessage
            // 
            this.checkBoxFDMessage.AutoSize = true;
            this.checkBoxFDMessage.Enabled = false;
            this.checkBoxFDMessage.Location = new System.Drawing.Point(674, 28);
            this.checkBoxFDMessage.Name = "checkBoxFDMessage";
            this.checkBoxFDMessage.Size = new System.Drawing.Size(40, 17);
            this.checkBoxFDMessage.TabIndex = 14;
            this.checkBoxFDMessage.Text = "FD";
            this.checkBoxFDMessage.UseVisualStyleBackColor = true;
            this.checkBoxFDMessage.Visible = false;
            this.checkBoxFDMessage.CheckedChanged += new System.EventHandler(this.checkBoxFDMessage_CheckedChanged);
            // 
            // numericUpDownRemoteAddr
            // 
            this.numericUpDownRemoteAddr.BackColor = System.Drawing.Color.White;
            this.numericUpDownRemoteAddr.Hexadecimal = true;
            this.numericUpDownRemoteAddr.Location = new System.Drawing.Point(413, 39);
            this.numericUpDownRemoteAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownRemoteAddr.Name = "numericUpDownRemoteAddr";
            this.numericUpDownRemoteAddr.Size = new System.Drawing.Size(65, 20);
            this.numericUpDownRemoteAddr.TabIndex = 7;
            // 
            // numericUpDownTargetAddr
            // 
            this.numericUpDownTargetAddr.BackColor = System.Drawing.Color.White;
            this.numericUpDownTargetAddr.Hexadecimal = true;
            this.numericUpDownTargetAddr.Location = new System.Drawing.Point(338, 39);
            this.numericUpDownTargetAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownTargetAddr.Name = "numericUpDownTargetAddr";
            this.numericUpDownTargetAddr.Size = new System.Drawing.Size(65, 20);
            this.numericUpDownTargetAddr.TabIndex = 5;
            // 
            // numericUpDownSourceAddr
            // 
            this.numericUpDownSourceAddr.BackColor = System.Drawing.Color.White;
            this.numericUpDownSourceAddr.Hexadecimal = true;
            this.numericUpDownSourceAddr.Location = new System.Drawing.Point(260, 39);
            this.numericUpDownSourceAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownSourceAddr.Name = "numericUpDownSourceAddr";
            this.numericUpDownSourceAddr.Size = new System.Drawing.Size(65, 20);
            this.numericUpDownSourceAddr.TabIndex = 3;
            // 
            // buttonMsgDataFill
            // 
            this.buttonMsgDataFill.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonMsgDataFill.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonMsgDataFill.Location = new System.Drawing.Point(565, 37);
            this.buttonMsgDataFill.Name = "buttonMsgDataFill";
            this.buttonMsgDataFill.Size = new System.Drawing.Size(65, 23);
            this.buttonMsgDataFill.TabIndex = 10;
            this.buttonMsgDataFill.Text = "Fill";
            this.buttonMsgDataFill.Click += new System.EventHandler(this.buttonMsgDataFill_Click);
            // 
            // labelMsgRemoteAddr
            // 
            this.labelMsgRemoteAddr.AutoSize = true;
            this.labelMsgRemoteAddr.Location = new System.Drawing.Point(410, 21);
            this.labelMsgRemoteAddr.Name = "labelMsgRemoteAddr";
            this.labelMsgRemoteAddr.Size = new System.Drawing.Size(75, 13);
            this.labelMsgRemoteAddr.TabIndex = 6;
            this.labelMsgRemoteAddr.Text = "Remote (Hex):";
            // 
            // labelMsgTargetAddr
            // 
            this.labelMsgTargetAddr.AutoSize = true;
            this.labelMsgTargetAddr.Location = new System.Drawing.Point(335, 21);
            this.labelMsgTargetAddr.Name = "labelMsgTargetAddr";
            this.labelMsgTargetAddr.Size = new System.Drawing.Size(69, 13);
            this.labelMsgTargetAddr.TabIndex = 4;
            this.labelMsgTargetAddr.Text = "Target (Hex):";
            // 
            // textBoxMsgData
            // 
            this.textBoxMsgData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxMsgData.Location = new System.Drawing.Point(9, 82);
            this.textBoxMsgData.MaxLength = 4095;
            this.textBoxMsgData.Multiline = true;
            this.textBoxMsgData.Name = "textBoxMsgData";
            this.textBoxMsgData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxMsgData.Size = new System.Drawing.Size(790, 61);
            this.textBoxMsgData.TabIndex = 12;
            this.textBoxMsgData.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxHexOnly_KeyPress);
            this.textBoxMsgData.Leave += new System.EventHandler(this.numericUpDownMsgLength_ValueChanged);
            // 
            // labelMsgMapping
            // 
            this.labelMsgMapping.AutoSize = true;
            this.labelMsgMapping.Location = new System.Drawing.Point(6, 21);
            this.labelMsgMapping.Name = "labelMsgMapping";
            this.labelMsgMapping.Size = new System.Drawing.Size(51, 13);
            this.labelMsgMapping.TabIndex = 0;
            this.labelMsgMapping.Text = "Mapping:";
            // 
            // comboBoxMsgMapping
            // 
            this.comboBoxMsgMapping.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMsgMapping.FormattingEnabled = true;
            this.comboBoxMsgMapping.Location = new System.Drawing.Point(9, 37);
            this.comboBoxMsgMapping.Name = "comboBoxMsgMapping";
            this.comboBoxMsgMapping.Size = new System.Drawing.Size(236, 21);
            this.comboBoxMsgMapping.TabIndex = 1;
            this.comboBoxMsgMapping.SelectedIndexChanged += new System.EventHandler(this.comboBoxMsgMapping_SelectedIndexChanged);
            // 
            // labelMsgData
            // 
            this.labelMsgData.AutoSize = true;
            this.labelMsgData.Location = new System.Drawing.Point(6, 66);
            this.labelMsgData.Name = "labelMsgData";
            this.labelMsgData.Size = new System.Drawing.Size(61, 13);
            this.labelMsgData.TabIndex = 11;
            this.labelMsgData.Text = "Data (Hex):";
            // 
            // buttonMsgWrite
            // 
            this.buttonMsgWrite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMsgWrite.Cursor = System.Windows.Forms.Cursors.Default;
            this.buttonMsgWrite.Enabled = false;
            this.buttonMsgWrite.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonMsgWrite.Location = new System.Drawing.Point(805, 80);
            this.buttonMsgWrite.Name = "buttonMsgWrite";
            this.buttonMsgWrite.Size = new System.Drawing.Size(65, 23);
            this.buttonMsgWrite.TabIndex = 13;
            this.buttonMsgWrite.Text = "Write";
            this.buttonMsgWrite.Click += new System.EventHandler(this.buttonMsgWrite_Click);
            // 
            // labelMsgLength
            // 
            this.labelMsgLength.AutoSize = true;
            this.labelMsgLength.Location = new System.Drawing.Point(491, 21);
            this.labelMsgLength.Name = "labelMsgLength";
            this.labelMsgLength.Size = new System.Drawing.Size(43, 13);
            this.labelMsgLength.TabIndex = 8;
            this.labelMsgLength.Text = "Length:";
            // 
            // labelMsgSourceAddr
            // 
            this.labelMsgSourceAddr.AutoSize = true;
            this.labelMsgSourceAddr.Location = new System.Drawing.Point(257, 21);
            this.labelMsgSourceAddr.Name = "labelMsgSourceAddr";
            this.labelMsgSourceAddr.Size = new System.Drawing.Size(72, 13);
            this.labelMsgSourceAddr.TabIndex = 2;
            this.labelMsgSourceAddr.Text = "Source (Hex):";
            // 
            // numericUpDownMsgLength
            // 
            this.numericUpDownMsgLength.BackColor = System.Drawing.Color.White;
            this.numericUpDownMsgLength.Location = new System.Drawing.Point(494, 39);
            this.numericUpDownMsgLength.Maximum = new decimal(new int[] {
            4095,
            0,
            0,
            0});
            this.numericUpDownMsgLength.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownMsgLength.Name = "numericUpDownMsgLength";
            this.numericUpDownMsgLength.Size = new System.Drawing.Size(65, 20);
            this.numericUpDownMsgLength.TabIndex = 9;
            this.numericUpDownMsgLength.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownMsgLength.ValueChanged += new System.EventHandler(this.numericUpDownMsgLength_ValueChanged);
            // 
            // timerDisplay
            // 
            this.timerDisplay.Tick += new System.EventHandler(this.timerDisplay_Tick);
            // 
            // timerRead
            // 
            this.timerRead.Interval = 50;
            this.timerRead.Tick += new System.EventHandler(this.timerRead_Tick);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 411);
            this.Controls.Add(this.tabControlMain);
            this.Controls.Add(this.groupBoxConnection);
            this.MinimumSize = new System.Drawing.Size(734, 450);
            this.Name = "FormMain";
            this.Text = "PCAN ISO-TP Example";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMain_FormClosed);
            this.Shown += new System.EventHandler(this.FormMain_Shown);
            this.groupBoxConnection.ResumeLayout(false);
            this.groupBoxConnection.PerformLayout();
            this.tabControlMain.ResumeLayout(false);
            this.tabPageParameters.ResumeLayout(false);
            this.groupBoxParamInfo.ResumeLayout(false);
            this.groupBoxParamCfg.ResumeLayout(false);
            this.groupBoxParamCfg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParamValue)).EndInit();
            this.tabPageMappings.ResumeLayout(false);
            this.tabPageMessages.ResumeLayout(false);
            this.groupBoxMsgRead.ResumeLayout(false);
            this.groupBoxMsgRead.PerformLayout();
            this.groupBoxMsgWrite.ResumeLayout(false);
            this.groupBoxMsgWrite.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemoteAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTargetAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSourceAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMsgLength)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxConnection;
        private System.Windows.Forms.ComboBox comboBoxHwType;
        private System.Windows.Forms.ComboBox comboBoxInterrupt;
        private System.Windows.Forms.Label labelConnInterrupt;
        private System.Windows.Forms.ComboBox comboBoxIoPort;
        private System.Windows.Forms.Label labelConnIoPort;
        private System.Windows.Forms.Label labelConnHwType;
        private System.Windows.Forms.ComboBox comboBoxBaudrate;
        private System.Windows.Forms.Label labelConnBaudrate;
        private System.Windows.Forms.Button buttonHwRefresh;
        private System.Windows.Forms.ComboBox comboBoxChannel;
        private System.Windows.Forms.Label labelConnHardware;
        private System.Windows.Forms.Button buttonInit;
        private System.Windows.Forms.Button buttonRelease;
        private System.Windows.Forms.TabControl tabControlMain;
        private System.Windows.Forms.TabPage tabPageMappings;
        private System.Windows.Forms.TabPage tabPageMessages;
        private System.Windows.Forms.ListView listViewMappings;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingCanId;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingSourceAddr;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingTargetAddr;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingMsgType;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingFormat;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingTargetType;
        private System.Windows.Forms.Button buttonMappingDel;
        private System.Windows.Forms.Button buttonMappingAdd;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingCanIdResponse;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingRemoteAddr;
        private System.Windows.Forms.ColumnHeader columnHeaderMappingCanIdType;
        private System.Windows.Forms.GroupBox groupBoxMsgRead;
        private System.Windows.Forms.CheckBox checkBoxMsgShowPeriod;
        private System.Windows.Forms.RadioButton radioButtonMsgManual;
        private System.Windows.Forms.RadioButton radioButtonMsgEvent;
        private System.Windows.Forms.ListView listViewMsgs;
        private System.Windows.Forms.Button buttonMsgClear;
        private System.Windows.Forms.RadioButton radioButtonMsgTimer;
        private System.Windows.Forms.Button buttonMsgRead;
        private System.Windows.Forms.GroupBox groupBoxMsgWrite;
        private System.Windows.Forms.Label labelMsgData;
        private System.Windows.Forms.Button buttonMsgWrite;
        private System.Windows.Forms.Label labelMsgLength;
        private System.Windows.Forms.NumericUpDown numericUpDownMsgLength;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgType;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgSourceAddr;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgTargetAddr;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgTargetType;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgLen;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgData;
        private System.Windows.Forms.Timer timerDisplay;
        private System.Windows.Forms.Timer timerRead;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgCount;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgTimestamp;
        private System.Windows.Forms.Button buttonMappingSample;
        private System.Windows.Forms.Label labelMsgMapping;
        private System.Windows.Forms.ComboBox comboBoxMsgMapping;
        private System.Windows.Forms.TextBox textBoxMsgData;
        private System.Windows.Forms.Label labelMsgTargetAddr;
        private System.Windows.Forms.Label labelMsgRemoteAddr;
        private System.Windows.Forms.Label labelMsgSourceAddr;
        private System.Windows.Forms.Button buttonMsgDataFill;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgIdType;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgFormat;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgResult;
        private System.Windows.Forms.ColumnHeader columnHeaderMsgRemoteAddr;
        private System.Windows.Forms.TabPage tabPageParameters;
        private System.Windows.Forms.GroupBox groupBoxParamInfo;
        private System.Windows.Forms.Button buttonParamReset;
        private System.Windows.Forms.Button buttonParamStatus;
        private System.Windows.Forms.Button buttonParamVersion;
        private System.Windows.Forms.ListBox listBoxParamInfo;
        private System.Windows.Forms.Button buttonParamInfoClear;
        private System.Windows.Forms.GroupBox groupBoxParamCfg;
        private System.Windows.Forms.Button buttonParamGet;
        private System.Windows.Forms.Label labelParamActivation;
        private System.Windows.Forms.NumericUpDown numericUpDownParamValue;
        private System.Windows.Forms.Label labelParamValue;
        private System.Windows.Forms.ComboBox comboBoxParameter;
        private System.Windows.Forms.Label labelParameter;
        private System.Windows.Forms.RadioButton radioButtonParamActive;
        private System.Windows.Forms.RadioButton radioButtonParamInactive;
        private System.Windows.Forms.Button buttonParamSet;
        private System.Windows.Forms.NumericUpDown numericUpDownRemoteAddr;
        private System.Windows.Forms.NumericUpDown numericUpDownTargetAddr;
        private System.Windows.Forms.NumericUpDown numericUpDownSourceAddr;
        private System.Windows.Forms.Button buttonMappingSave;
        private System.Windows.Forms.Button buttonMappingLoad;
        private System.Windows.Forms.TextBox textBoxCanFdBitrate;
        private System.Windows.Forms.CheckBox checkBoxCanFd;
        private System.Windows.Forms.Label labelConnBitRate;
        private System.Windows.Forms.NumericUpDown numericUpDownPriority;
        private System.Windows.Forms.CheckBox checkBoxHasPriority;
        private System.Windows.Forms.CheckBox checkBoxBRS;
        private System.Windows.Forms.CheckBox checkBoxFDMessage;
    }
}

