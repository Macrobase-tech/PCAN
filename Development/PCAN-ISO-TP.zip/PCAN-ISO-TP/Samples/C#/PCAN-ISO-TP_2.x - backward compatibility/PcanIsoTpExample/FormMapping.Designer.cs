﻿namespace PcanIsoTpExample
{
    partial class FormMapping
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxFormat = new System.Windows.Forms.ComboBox();
            this.comboBoxMsgType = new System.Windows.Forms.ComboBox();
            this.comboBoxTargetType = new System.Windows.Forms.ComboBox();
            this.numericUpDownSourceAddr = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownTargetAddr = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownRemoteAddr = new System.Windows.Forms.NumericUpDown();
            this.labelCanIdResp = new System.Windows.Forms.Label();
            this.labelCanId = new System.Windows.Forms.Label();
            this.labelFormat = new System.Windows.Forms.Label();
            this.numericUpDownCanId = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCanIdResp = new System.Windows.Forms.NumericUpDown();
            this.radioButtonCanId11b = new System.Windows.Forms.RadioButton();
            this.radioButtonCanId29b = new System.Windows.Forms.RadioButton();
            this.labelCanIdType = new System.Windows.Forms.Label();
            this.labelMsgType = new System.Windows.Forms.Label();
            this.labelTargetType = new System.Windows.Forms.Label();
            this.labelSrcAddr = new System.Windows.Forms.Label();
            this.labelTargetAddr = new System.Windows.Forms.Label();
            this.labelRemoteAddr = new System.Windows.Forms.Label();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSourceAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTargetAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemoteAddr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCanId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCanIdResp)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxFormat
            // 
            this.comboBoxFormat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFormat.FormattingEnabled = true;
            this.comboBoxFormat.Location = new System.Drawing.Point(143, 56);
            this.comboBoxFormat.Name = "comboBoxFormat";
            this.comboBoxFormat.Size = new System.Drawing.Size(291, 21);
            this.comboBoxFormat.TabIndex = 7;
            this.comboBoxFormat.SelectedIndexChanged += new System.EventHandler(this.comboBoxFormat_SelectedIndexChanged);
            this.comboBoxFormat.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // comboBoxMsgType
            // 
            this.comboBoxMsgType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxMsgType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMsgType.FormattingEnabled = true;
            this.comboBoxMsgType.Location = new System.Drawing.Point(143, 29);
            this.comboBoxMsgType.Name = "comboBoxMsgType";
            this.comboBoxMsgType.Size = new System.Drawing.Size(291, 21);
            this.comboBoxMsgType.TabIndex = 5;
            this.comboBoxMsgType.SelectedIndexChanged += new System.EventHandler(this.comboBoxMsgType_SelectedIndexChanged);
            this.comboBoxMsgType.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // comboBoxTargetType
            // 
            this.comboBoxTargetType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxTargetType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTargetType.FormattingEnabled = true;
            this.comboBoxTargetType.Location = new System.Drawing.Point(143, 83);
            this.comboBoxTargetType.Name = "comboBoxTargetType";
            this.comboBoxTargetType.Size = new System.Drawing.Size(291, 21);
            this.comboBoxTargetType.TabIndex = 9;
            this.comboBoxTargetType.SelectedIndexChanged += new System.EventHandler(this.comboBoxTargetType_SelectedIndexChanged);
            this.comboBoxTargetType.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // numericUpDownSourceAddr
            // 
            this.numericUpDownSourceAddr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownSourceAddr.Hexadecimal = true;
            this.numericUpDownSourceAddr.Location = new System.Drawing.Point(143, 163);
            this.numericUpDownSourceAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownSourceAddr.Name = "numericUpDownSourceAddr";
            this.numericUpDownSourceAddr.Size = new System.Drawing.Size(291, 20);
            this.numericUpDownSourceAddr.TabIndex = 15;
            this.numericUpDownSourceAddr.ValueChanged += new System.EventHandler(this.numericUpDownComponents_ValueChanged);
            this.numericUpDownSourceAddr.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // numericUpDownTargetAddr
            // 
            this.numericUpDownTargetAddr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownTargetAddr.Hexadecimal = true;
            this.numericUpDownTargetAddr.Location = new System.Drawing.Point(143, 189);
            this.numericUpDownTargetAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownTargetAddr.Name = "numericUpDownTargetAddr";
            this.numericUpDownTargetAddr.Size = new System.Drawing.Size(291, 20);
            this.numericUpDownTargetAddr.TabIndex = 17;
            this.numericUpDownTargetAddr.ValueChanged += new System.EventHandler(this.numericUpDownComponents_ValueChanged);
            this.numericUpDownTargetAddr.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // numericUpDownRemoteAddr
            // 
            this.numericUpDownRemoteAddr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownRemoteAddr.Hexadecimal = true;
            this.numericUpDownRemoteAddr.Location = new System.Drawing.Point(143, 215);
            this.numericUpDownRemoteAddr.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownRemoteAddr.Name = "numericUpDownRemoteAddr";
            this.numericUpDownRemoteAddr.Size = new System.Drawing.Size(291, 20);
            this.numericUpDownRemoteAddr.TabIndex = 19;
            this.numericUpDownRemoteAddr.ValueChanged += new System.EventHandler(this.numericUpDownComponents_ValueChanged);
            this.numericUpDownRemoteAddr.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // labelCanIdResp
            // 
            this.labelCanIdResp.AutoSize = true;
            this.labelCanIdResp.Location = new System.Drawing.Point(12, 138);
            this.labelCanIdResp.Name = "labelCanIdResp";
            this.labelCanIdResp.Size = new System.Drawing.Size(118, 13);
            this.labelCanIdResp.TabIndex = 12;
            this.labelCanIdResp.Text = "CAN ID response (hex):";
            // 
            // labelCanId
            // 
            this.labelCanId.AutoSize = true;
            this.labelCanId.Location = new System.Drawing.Point(12, 112);
            this.labelCanId.Name = "labelCanId";
            this.labelCanId.Size = new System.Drawing.Size(72, 13);
            this.labelCanId.TabIndex = 10;
            this.labelCanId.Text = "CAN ID (hex):";
            // 
            // labelFormat
            // 
            this.labelFormat.AutoSize = true;
            this.labelFormat.Location = new System.Drawing.Point(12, 59);
            this.labelFormat.Name = "labelFormat";
            this.labelFormat.Size = new System.Drawing.Size(65, 13);
            this.labelFormat.TabIndex = 6;
            this.labelFormat.Text = "Format type:";
            // 
            // numericUpDownCanId
            // 
            this.numericUpDownCanId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownCanId.Hexadecimal = true;
            this.numericUpDownCanId.Location = new System.Drawing.Point(143, 110);
            this.numericUpDownCanId.Name = "numericUpDownCanId";
            this.numericUpDownCanId.Size = new System.Drawing.Size(291, 20);
            this.numericUpDownCanId.TabIndex = 11;
            this.numericUpDownCanId.ValueChanged += new System.EventHandler(this.numericUpDownComponents_ValueChanged);
            this.numericUpDownCanId.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // numericUpDownCanIdResp
            // 
            this.numericUpDownCanIdResp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDownCanIdResp.Hexadecimal = true;
            this.numericUpDownCanIdResp.Location = new System.Drawing.Point(143, 136);
            this.numericUpDownCanIdResp.Name = "numericUpDownCanIdResp";
            this.numericUpDownCanIdResp.Size = new System.Drawing.Size(291, 20);
            this.numericUpDownCanIdResp.TabIndex = 13;
            this.numericUpDownCanIdResp.ValueChanged += new System.EventHandler(this.numericUpDownComponents_ValueChanged);
            this.numericUpDownCanIdResp.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // radioButtonCanId11b
            // 
            this.radioButtonCanId11b.AutoSize = true;
            this.radioButtonCanId11b.Location = new System.Drawing.Point(143, 7);
            this.radioButtonCanId11b.Name = "radioButtonCanId11b";
            this.radioButtonCanId11b.Size = new System.Drawing.Size(56, 17);
            this.radioButtonCanId11b.TabIndex = 2;
            this.radioButtonCanId11b.TabStop = true;
            this.radioButtonCanId11b.Text = "11 bits";
            this.radioButtonCanId11b.UseVisualStyleBackColor = true;
            this.radioButtonCanId11b.CheckedChanged += new System.EventHandler(this.radioButtonCanId_CheckedChanged);
            this.radioButtonCanId11b.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // radioButtonCanId29b
            // 
            this.radioButtonCanId29b.AutoSize = true;
            this.radioButtonCanId29b.Location = new System.Drawing.Point(205, 7);
            this.radioButtonCanId29b.Name = "radioButtonCanId29b";
            this.radioButtonCanId29b.Size = new System.Drawing.Size(56, 17);
            this.radioButtonCanId29b.TabIndex = 3;
            this.radioButtonCanId29b.TabStop = true;
            this.radioButtonCanId29b.Text = "29 bits";
            this.radioButtonCanId29b.UseVisualStyleBackColor = true;
            this.radioButtonCanId29b.CheckedChanged += new System.EventHandler(this.radioButtonCanId_CheckedChanged);
            this.radioButtonCanId29b.Leave += new System.EventHandler(this.uiComponent_Leave);
            // 
            // labelCanIdType
            // 
            this.labelCanIdType.AutoSize = true;
            this.labelCanIdType.Location = new System.Drawing.Point(12, 9);
            this.labelCanIdType.Name = "labelCanIdType";
            this.labelCanIdType.Size = new System.Drawing.Size(69, 13);
            this.labelCanIdType.TabIndex = 1;
            this.labelCanIdType.Text = "CAN ID type:";
            // 
            // labelMsgType
            // 
            this.labelMsgType.AutoSize = true;
            this.labelMsgType.Location = new System.Drawing.Point(12, 32);
            this.labelMsgType.Name = "labelMsgType";
            this.labelMsgType.Size = new System.Drawing.Size(76, 13);
            this.labelMsgType.TabIndex = 4;
            this.labelMsgType.Text = "Message type:";
            // 
            // labelTargetType
            // 
            this.labelTargetType.AutoSize = true;
            this.labelTargetType.Location = new System.Drawing.Point(12, 86);
            this.labelTargetType.Name = "labelTargetType";
            this.labelTargetType.Size = new System.Drawing.Size(118, 13);
            this.labelTargetType.TabIndex = 8;
            this.labelTargetType.Text = "Target addressing type:";
            // 
            // labelSrcAddr
            // 
            this.labelSrcAddr.AutoSize = true;
            this.labelSrcAddr.Location = new System.Drawing.Point(12, 165);
            this.labelSrcAddr.Name = "labelSrcAddr";
            this.labelSrcAddr.Size = new System.Drawing.Size(110, 13);
            this.labelSrcAddr.TabIndex = 14;
            this.labelSrcAddr.Text = "Source address (hex):";
            // 
            // labelTargetAddr
            // 
            this.labelTargetAddr.AutoSize = true;
            this.labelTargetAddr.Location = new System.Drawing.Point(12, 191);
            this.labelTargetAddr.Name = "labelTargetAddr";
            this.labelTargetAddr.Size = new System.Drawing.Size(107, 13);
            this.labelTargetAddr.TabIndex = 16;
            this.labelTargetAddr.Text = "Target address (hex):";
            // 
            // labelRemoteAddr
            // 
            this.labelRemoteAddr.AutoSize = true;
            this.labelRemoteAddr.Location = new System.Drawing.Point(12, 217);
            this.labelRemoteAddr.Name = "labelRemoteAddr";
            this.labelRemoteAddr.Size = new System.Drawing.Size(113, 13);
            this.labelRemoteAddr.TabIndex = 18;
            this.labelRemoteAddr.Text = "Remote address (hex):";
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(359, 254);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 21;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonOk
            // 
            this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOk.Location = new System.Drawing.Point(278, 254);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 20;
            this.buttonOk.Text = "OK";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // FormMapping
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 289);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.labelRemoteAddr);
            this.Controls.Add(this.labelTargetAddr);
            this.Controls.Add(this.labelSrcAddr);
            this.Controls.Add(this.labelTargetType);
            this.Controls.Add(this.labelMsgType);
            this.Controls.Add(this.labelCanIdType);
            this.Controls.Add(this.radioButtonCanId29b);
            this.Controls.Add(this.radioButtonCanId11b);
            this.Controls.Add(this.numericUpDownCanIdResp);
            this.Controls.Add(this.numericUpDownCanId);
            this.Controls.Add(this.labelFormat);
            this.Controls.Add(this.labelCanId);
            this.Controls.Add(this.labelCanIdResp);
            this.Controls.Add(this.numericUpDownRemoteAddr);
            this.Controls.Add(this.numericUpDownTargetAddr);
            this.Controls.Add(this.numericUpDownSourceAddr);
            this.Controls.Add(this.comboBoxTargetType);
            this.Controls.Add(this.comboBoxMsgType);
            this.Controls.Add(this.comboBoxFormat);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormMapping";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ISO-TP Mapping";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSourceAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTargetAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownRemoteAddr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCanId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCanIdResp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBoxFormat;
        private System.Windows.Forms.ComboBox comboBoxMsgType;
        private System.Windows.Forms.ComboBox comboBoxTargetType;
        private System.Windows.Forms.NumericUpDown numericUpDownSourceAddr;
        private System.Windows.Forms.NumericUpDown numericUpDownTargetAddr;
        private System.Windows.Forms.NumericUpDown numericUpDownRemoteAddr;
        private System.Windows.Forms.Label labelCanIdResp;
        private System.Windows.Forms.Label labelCanId;
        private System.Windows.Forms.Label labelFormat;
        private System.Windows.Forms.NumericUpDown numericUpDownCanId;
        private System.Windows.Forms.NumericUpDown numericUpDownCanIdResp;
        private System.Windows.Forms.RadioButton radioButtonCanId11b;
        private System.Windows.Forms.RadioButton radioButtonCanId29b;
        private System.Windows.Forms.Label labelCanIdType;
        private System.Windows.Forms.Label labelMsgType;
        private System.Windows.Forms.Label labelTargetType;
        private System.Windows.Forms.Label labelSrcAddr;
        private System.Windows.Forms.Label labelTargetAddr;
        private System.Windows.Forms.Label labelRemoteAddr;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonOk;
    }
}