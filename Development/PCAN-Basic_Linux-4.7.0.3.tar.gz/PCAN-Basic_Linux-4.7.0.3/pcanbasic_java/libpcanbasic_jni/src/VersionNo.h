#define FILEVER 4,7,0,1
#define STRFILEVER "4.7.0.1"
#define STRPRODUCTVER "4.7"
#define COPYRIGHT "(C) 2023 PEAK-System Technik GmbH"
// linux API
#define VERSION_MAJOR		4
#define VERSION_MINOR		7
#define VERSION_PATCH		0
#define VERSION_BUILD		1

